<?php

namespace CodeBerry\ProductApi\Model;

use CodeBerry\ProductApi\Api\MyApiInterface;
use Magento\Catalog\Api\Data\ProductInterface;
use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Framework\Exception\NoSuchEntityException;

class MyApi implements MyApiInterface
{
    /**
     * @var ProductRepositoryInterface
     */
    private $productRepository;

    /**
     * MyApi constructor.
     * @param ProductRepositoryInterface $productRepository
     */
    public function __construct(
        ProductRepositoryInterface $productRepository
    ) {
        $this->productRepository = $productRepository;
    }

    /**
     * Get product by ID
     *
     * @param int $productId
     * @return ProductInterface
     * @throws NoSuchEntityException
     */
    public function getProductById($productId)
    {
        return $this->productRepository->getById($productId);
    }
}
