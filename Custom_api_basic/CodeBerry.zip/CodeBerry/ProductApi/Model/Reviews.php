<?php
namespace CodeBerry\ProductApi\Model;

use Magento\Review\Model\ResourceModel\Review\CollectionFactory;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Framework\Api\FilterBuilder;
use CodeBerry\ProductApi\Api\ReviewsInterface;

class Reviews implements ReviewsInterface
{
    /**
     * @var CollectionFactory
     */
    protected $reviewCollectionFactory;

    /**
     * @var SearchCriteriaBuilder
     */
    protected $searchCriteriaBuilder;

    /**
     * @var FilterBuilder
     */
    protected $filterBuilder;

    /**
     * @param CollectionFactory $reviewCollectionFactory
     * @param SearchCriteriaBuilder $searchCriteriaBuilder
     * @param FilterBuilder $filterBuilder
     */
    public function __construct(
        CollectionFactory $reviewCollectionFactory,
        SearchCriteriaBuilder $searchCriteriaBuilder,
        FilterBuilder $filterBuilder
    ) {
        $this->reviewCollectionFactory = $reviewCollectionFactory;
        $this->searchCriteriaBuilder = $searchCriteriaBuilder;
        $this->filterBuilder = $filterBuilder;
    }

    /**
     * {@inheritdoc}
     */
    public function getProductReviews($productId)
    {
        $reviewsCollection = $this->reviewCollectionFactory->create()
            ->addStatusFilter(\Magento\Review\Model\Review::STATUS_APPROVED)
            ->addEntityFilter('product', $productId)
            ->setDateOrder();

        $reviews = [];
        foreach ($reviewsCollection as $review) {
            $reviews[] = [
                'id' => $review->getId(),
                'title' => $review->getTitle(),
                'detail' => $review->getDetail(),
                'nickname' => $review->getNickname(),
                'rating' => $review->getRatingSummary(),
                'created_at' => $review->getCreatedAt(),
            ];
        }

        return $reviews;
    }
}
