<?php

namespace CodeBerry\ProductApi\Model;

use CodeBerry\ProductApi\Api\ProductRepositoryInterface;
use Magento\Catalog\Api\Data\ProductInterface;
use Magento\Catalog\Api\ProductRepositoryInterface as CatalogProductRepositoryInterface;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Framework\Api\SearchCriteriaBuilderFactory;

class ProductRepository implements ProductRepositoryInterface
{
    /**
     * @var CatalogProductRepositoryInterface
     */
    private $catalogProductRepository;

    /**
     * @var SearchCriteriaBuilderFactory
     */
    private $searchCriteriaBuilderFactory;

    public function __construct(
        CatalogProductRepositoryInterface $catalogProductRepository,
        SearchCriteriaBuilderFactory $searchCriteriaBuilderFactory
    ) {
        $this->catalogProductRepository = $catalogProductRepository;
        $this->searchCriteriaBuilderFactory = $searchCriteriaBuilderFactory;
    }

    /**
     * {@inheritdoc}
     */
    public function getList($pageSize = null, $currentPage = null)
    {
        /** @var SearchCriteriaBuilder $searchCriteriaBuilder */
        $searchCriteriaBuilder = $this->searchCriteriaBuilderFactory->create();
        $searchCriteriaBuilder->setPageSize($pageSize ?: 10);
        $searchCriteriaBuilder->setCurrentPage($currentPage ?: 1);

        $searchCriteria = $searchCriteriaBuilder->create();

        $products = $this->catalogProductRepository->getList($searchCriteria)->getItems();
        $result = [];
        /** @var ProductInterface $product */
        foreach ($products as $product) {
            $result[] = [
                'id' => $product->getId(),
                'name' => $product->getName(),
                'price' => $product->getPrice()
            ];
        }
        return $result;
    }
}
