<?php

namespace CodeBerry\ProductApi\Api;

interface ProductRepositoryInterface
{
    /**
     * @param int $pageSize
     * @param int $currentPage
     * @return mixed
     */
    public function getList($pageSize = 10, $currentPage = 1);
}
