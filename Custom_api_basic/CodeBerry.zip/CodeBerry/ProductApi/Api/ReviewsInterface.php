<?php
namespace CodeBerry\ProductApi\Api;

interface ReviewsInterface
{
    /**
     * @param int $productId
     * @return array
     */
    public function getProductReviews($productId);
}