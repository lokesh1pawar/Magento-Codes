<?php

namespace CodeBerry\ProductApi\Api;

interface MyApiInterface
{
    /**
     * Get product by ID
     *
     * @param int $productId
     * @return \Magento\Catalog\Api\Data\ProductInterface
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function getProductById($productId);
}
