<?php
namespace Thecoachsmb\ContactExtend\Model\ResourceModel\Contact;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    protected $_idFieldName = 'id';
    protected $_eventPrefix = 'thecoachsmb_contactextend_contact_collection';
    protected $_eventObject = 'contact_collection';

    /**
     * Define the resource model & the model.
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Thecoachsmb\ContactExtend\Model\Contact', 'Thecoachsmb\ContactExtend\Model\ResourceModel\Contact');
    }
}
