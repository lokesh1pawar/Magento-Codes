<?php
namespace Plumtree\ProductActionExtended\Plugin;

use Magento\Framework\View\Element\UiComponent\ContextInterface;
use Magento\Framework\View\Element\UiComponentFactory;
use Magento\Ui\Component\Listing\Columns\Column;
use Magento\Framework\UrlInterface;

class ProdExtend
{
    public function __construct(
        ContextInterface $context,
        UiComponentFactory $uiComponentFactory,
        UrlInterface $urlBuilder,
        array $components = [],
        array $data = []
    ) {
        $this->urlBuilder = $urlBuilder;
        $this->context = $context;
        // parent::__construct($context, $uiComponentFactory, $components, $data);
    }

    public function afterPrepareDataSource(\Magento\Catalog\Ui\Component\Listing\Columns\ProductActions $subject, array $dataSource, $result)
    {
        if (isset($result['data']['items'])) {
            $storeId = $this->context->getFilterParam('store_id');
            foreach ($result['data']['items'] as &$item) {
                $item[$subject->getData('name')]['edit'] = [

                    'ariaLabel' => __('Edit ') . @$item['name'],
                   
                ];
            }
        }
        // echo "<pre>";
        // print_r($dataSource);
        // print_r($result);
        // echo "</pre>";

        // exit();
        return $result;
    }
}
