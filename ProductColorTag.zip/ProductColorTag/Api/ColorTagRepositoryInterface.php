<?php
namespace SoftWebPos\ProductColorTag\Api;

interface ColorTagRepositoryInterface
{
	public function save(\SoftWebPos\ProductColorTag\Api\Data\ColorTagInterface $colortag);

    public function getByEntityId($entity_id);

    public function delete(\SoftWebPos\ProductColorTag\Api\Data\ColorTagInterface $colortag);

    public function deleteByEntityId($entity_id);
}