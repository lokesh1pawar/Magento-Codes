<?php
namespace SoftWebPos\ProductColorTag\Api\Data;

interface ColorTagInterface
{
    const ENTITY_ID 	= 'entity_id';
    const TITLE 	= 'title';
    const CREATE_BY 	= 'create_by';
    const CREATED_AT 	= 'created_at';    
    
	public function getEntityId();

    public function setEntityId($entity_id);

    public function getTitle();

    public function setTitle($title);

    public function getCreateBy();

	public function setCreateBy($create_by);

    public function getCreatedAt();

	public function setCreatedAt($created_at);
}