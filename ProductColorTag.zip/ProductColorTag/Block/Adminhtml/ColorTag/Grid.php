<?php
namespace SoftWebPos\ProductColorTag\Block\Adminhtml\ColorTag;

class Grid extends \Magento\Backend\Block\Widget\Grid
{
 
}
