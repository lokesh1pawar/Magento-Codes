<?php
namespace SoftWebPos\ProductColorTag\Block\Adminhtml;

class ColorTag extends \Magento\Backend\Block\Widget\Grid\Container
{
    protected function _construct()
    {
        $this->_controller = 'adminhtml_colortag';
        $this->_blockGroup = 'SoftWebPos_colortag';
        $this->_headerText = __('Manage Color Tag');

        parent::_construct();

        if ($this->_isAllowedAction('SoftWebPos_colortag::save')) {
            $this->buttonList->update('add', 'label', __('Add Color Tag'));
        } else {
            $this->buttonList->remove('add');
        }
    }

    protected function _isAllowedAction($resourceId)
    {
        return $this->_authorization->isAllowed($resourceId);
    }
}
