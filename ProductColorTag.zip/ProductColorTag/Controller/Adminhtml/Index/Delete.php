<?php

namespace SoftWebPos\ProductColorTag\Controller\Adminhtml\Index;

class Delete extends \Magento\Backend\App\Action
{
	/**
     * Delete action
     *
     * @return \Magento\Backend\Model\View\Result\Redirect
     */
    public function execute()
    {
        // check if we know what should be deleted
        $id = $this->getRequest()->getParam('entity_id');
        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        if ($id) {
            try {
                // init model and delete
                $model = $this->_objectManager->create(\SoftWebPos\ProductColorTag\Model\ColorTag::class);
                $model->load($id);
                $deletedTitle = $model->getTitle();
                $model->delete();
                // display success message 
                $msg = '<b>'. $deletedTitle .'</b> has been deleted.';
                $this->messageManager->addSuccess(__($msg));
                
                return $resultRedirect->setPath('*/*/');
            } catch (\Exception $e) {
                // display error message
                $this->messageManager->addError($e->getMessage());
                // go back to edit form
                return $resultRedirect->setPath('*/*/edit', ['entity_id' => $id]);
            }
        }
        // display error message
        $this->messageManager->addError(__('We can\'t find a Color tag to delete.'));
        // go to grid
        return $resultRedirect->setPath('*/*/');
    }
}
