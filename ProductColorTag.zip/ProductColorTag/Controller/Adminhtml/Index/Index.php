<?php

namespace SoftWebPos\ProductColorTag\Controller\Adminhtml\Index;

class Index extends \Magento\Backend\App\Action
{
	const ADMIN_RESOURCE = 'SoftWebPos_ProductColorTag::colortaglist';

	/**
     * @var \Magento\Framework\View\Result\PageFactory
     */
	protected $resultPageFactory = false;

	/**
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Magento\Framework\View\Result\PageFactory $resultPageFactory
     */
	public function __construct(
		\Magento\Backend\App\Action\Context $context,
		\Magento\Framework\View\Result\PageFactory $resultPageFactory
	)
	{
		parent::__construct($context);
		$this->resultPageFactory = $resultPageFactory;
	}

	public function execute()
	{
		$resultPage = $this->resultPageFactory->create();
		$resultPage->getConfig()->getTitle()->prepend((__('Product Color Tag List')));

		return $resultPage;
	}
}