<?php

namespace SoftWebPos\ProductColorTag\Controller\Adminhtml\Index;

use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use SoftWebPos\ProductColorTag\Model\ColorTagFactory;
use SoftWebPos\ProductColorTag\Model\ImageUploader;
use \Magento\Backend\Model\Auth\Session;
use Magento\Framework\Stdlib\DateTime\TimezoneInterface;

class Save extends Action
{
    /**
     * @var \Magento\Framework\View\Result\PageFactory
     */
    protected $resultPageFactory;

    /**
     * @param Context $context
     * @param ColorTagFactory $ColorTagFactory
     */
    public function __construct(
        Context $context,
        ColorTagFactory $ColorTagFactory,
        ImageUploader $imageUploaderModel,
        Session $authSession,
        TimezoneInterface $timezoneInterface
    ) {
        parent::__construct($context);
        $this->ColorTagFactory = $ColorTagFactory;
        $this->imageUploaderModel = $imageUploaderModel;
        $this->authSession = $authSession;
        $this->timezoneInterface = $timezoneInterface;
    }

    /**
     * Execute
     *
     * @return \Magento\Framework\View\Result\PageFactory
     */
    public function execute()
    {
        $userId = $this->authSession->getUser()->getId();
        $todayDateTime = $this->timezoneInterface->date()->format('Y-m-d H:i:s');

        $resultRedirect = $this->resultRedirectFactory->create();
        if (!$this->getRequest()->getParams()) {
            $this->messageManager->addError(__("Something went wrong"));
            return $resultRedirect->setPath('*/*/index');
        }
        try {
            $model = $this->ColorTagFactory->create();
            $params = $this->getRequest()->getParams();
            if ($this->getRequest()->getParam('entity_id')) {
                $model->load($this->getRequest()->getParam('entity_id'));
            }else {
                $params['create_by'] = $userId;
                $params['created_at'] = $todayDateTime;
            }

            $model->setData($params);
            $model = $this->imageData($model, $params);
            $model->save();
            if ($model->getId()) {
                $this->messageManager->addSuccess(__("Data saved successfully"));
                return $resultRedirect->setPath('*/*/index');
            }
        } catch (\Exception $e) {
            $this->messageManager->addError(__("Something went wrong"));
            return $resultRedirect->setPath('*/*/edit');
        }
    }

    /**
     * @param $model
     * @param $data
     * @return mixed
     */
    public function imageData($model, $data)
    {
        if ($model->getId()) {
            $pageData = $this->helloworldFactory->create();
            $pageData->load($model->getId());
            if (isset($data['image'][0]['name'])) {
                $imageName1 = $pageData->getThumbnail();
                $imageName2 = $data['image'][0]['name'];
                if ($imageName1 != $imageName2) {
                    $imageUrl = $data['image'][0]['url'];
                    $imageName = $data['image'][0]['name'];
                    $data['image'] = $this->imageUploaderModel->saveMediaImage($imageName, $imageUrl);
                } else {
                    $data['image'] = $data['image'][0]['name'];
                }
            } else {
                $data['image'] = '';
            }
        } else {
            if (isset($data['image'][0]['name'])) {
                $imageUrl = $data['image'][0]['url'];
                $imageName = $data['image'][0]['name'];
                $data['image'] = $this->imageUploaderModel->saveMediaImage($imageName, $imageUrl);
            }
        }
        $model->setData($data);
        return $model;
    }
}