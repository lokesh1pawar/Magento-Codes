<?php
namespace SoftWebPos\ProductColorTag\Model\ColorTag;

use SoftWebPos\ProductColorTag\Model\ResourceModel\ColorTag\CollectionFactory;
use Magento\Framework\App\Request\DataPersistorInterface;
use Magento\Store\Model\StoreManagerInterface;

/**
 * Class DataProvider
 */
class DataProvider extends \Magento\Ui\DataProvider\AbstractDataProvider
{
    /**
     * @var \SoftWebPos\ProductColorTag\Model\ResourceModel\ColorTag\Collection
     */
    protected $collection;

    /**
     * @var DataPersistorInterface
     */
    protected $dataPersistor;

    /**
     * @var array
     */
    protected $loadedData;

    /**
     * @param string $name
     * @param string $primaryFieldName
     * @param string $requestFieldName
     * @param CollectionFactory $reasonCollectionFactory
     * @param DataPersistorInterface $dataPersistor
     * @param array $meta
     * @param array $data
     */
    public function __construct(
        $name,
        $primaryFieldName,
        $requestFieldName,
        CollectionFactory $reasonCollectionFactory,
        DataPersistorInterface $dataPersistor,
        StoreManagerInterface $storeManager,
        array $meta = [],
        array $data = []
    ) {
        $this->collection = $reasonCollectionFactory->create();
        $this->dataPersistor = $dataPersistor;
        $this->storeManager = $storeManager;
        parent::__construct($name, $primaryFieldName, $requestFieldName, $meta, $data);
        $this->meta = $this->prepareMeta($this->meta);
    }

    /**
     * Prepares Meta
     *
     * @param array $meta
     * @return array
     */
    public function prepareMeta(array $meta)
    {
        return $meta;
    }

    /**
     * Get data
     *
     * @return array
     */
    public function getData()
    {
        if (isset($this->loadedData)) {
            return $this->loadedData;
        }
        $items = $this->collection->getItems();
        /** @var $reason \SoftWebPos\ProductColorTag\Model\ColorTag */
        foreach ($items as $color) {
            $this->loadedData[$color->getEntityId()] = $color->getData();
            if ($color->getImage()) {
                $m['image'][0]['name'] = $color->getImage();
                $m['image'][0]['url'] = $this->getMediaUrl($color->getImage());
                $fullData = $this->loadedData;
                $this->loadedData[$color->getId()] = array_merge($fullData[$color->getId()], $m);
            }
        }

        $data = $this->dataPersistor->get('ColorTag');
        if (!empty($data)) {
            $color = $this->collection->getNewEmptyItem();
            $color->setData($data);
            $this->loadedData[$color->getEntityId()] = $color->getData();
            $this->dataPersistor->clear('ColorTag');
        }

        return $this->loadedData;
    }

    public function getMediaUrl($path = '')
    {
        $mediaUrl = $this->storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA) . 'wysiwyg/colortag/' . $path;
        return $mediaUrl;
    }
}
