<?php

namespace SoftWebPos\ProductColorTag\Model\Config\Source;

use Magento\Eav\Model\Entity\Attribute\Source\AbstractSource;

class ColorTagOptions extends AbstractSource {

    protected $resourceConnection;
    protected $imageBadgeFactory;

    public function __construct(
        \Magento\Framework\App\ResourceConnection $resourceConnection, 
        \SoftWebPos\ProductColorTag\Model\ResourceModel\ColorTag\CollectionFactory $ColorTagFactory
    ) {
        $this->resourceConnection = $resourceConnection;
        $this->ColorTagFactory = $ColorTagFactory;
    }

    /**
     * Get all options
     *
     * @return array
     */
    public function getAllOptions() {

        $collection = $this->ColorTagFactory->create();
        
        $this->_options[] = [
            'label' => __('Select Tag'),
            'value' => '',
        ];

        foreach ($collection as $item) {
            $this->_options[] = [
                'label' => __($item['title']),
                'value' => $item['entity_id'],
            ];
        }

        return $this->_options;
    }
}