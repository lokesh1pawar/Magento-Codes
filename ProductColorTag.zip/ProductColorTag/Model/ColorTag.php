<?php

namespace SoftWebPos\ProductColorTag\Model;

use Magento\Framework\Model\AbstractModel;
use SoftWebPos\ProductColorTag\Model\ResourceModel\ColorTag as ResourceModel;

class ColorTag extends AbstractModel implements \SoftWebPos\ProductColorTag\Api\Data\ColorTagInterface
{
    protected function _construct()
    {
        $this->_init(ResourceModel::class);
    }

    public function getEntityId(){
        return parent::getData(self::ENTITY_ID);
    }

    public function setEntityId($entity_id){
        return $this->setData(self::ENTITY_ID, $entity_id);
    }

    public function getTitle(){
        return parent::getData(self::TITLE);
    }

    public function setTitle($title){
        return $this->setData(self::TITLE, $title);
    }

    public function getCreateBy(){
        return parent::getData(self::CREATE_BY);
    }

    public function setCreateBy($create_by){
        return $this->setData(self::CREATE_BY, $create_by);
    }

    public function getCreatedAt(){
        return parent::getData(self::CREATED_AT);
    }

    public function setCreatedAt($created_at){
        return $this->setData(self::CREATED_AT, $created_at);
    }
}