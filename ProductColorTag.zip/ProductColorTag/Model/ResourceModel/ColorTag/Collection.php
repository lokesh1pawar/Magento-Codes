<?php
namespace SoftWebPos\ProductColorTag\Model\ResourceModel\ColorTag;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;
use SoftWebPos\ProductColorTag\Model\ColorTag as Model;
use SoftWebPos\ProductColorTag\Model\ResourceModel\ColorTag as ResourceModel;

class Collection extends AbstractCollection
{
    protected function _construct()
    {
        $this->_init(Model::class, ResourceModel::class);
    }
}