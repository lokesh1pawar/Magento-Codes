<?php
\Magento\Framework\Component\ComponentRegistrar::register(
	\Magento\Framework\Component\ComponentRegistrar::MODULE,
	'Nordcomputer_Showoutofstockprice',
	__DIR__
);
