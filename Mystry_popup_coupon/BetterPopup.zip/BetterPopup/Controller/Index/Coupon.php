<?php
namespace MagePlaza\BetterPopup\Controller\Index;

use Exception;
use Psr\Log\LoggerInterface;
use Magento\Backend\App\Action\Context;
use Magento\Framework\App\Action\Action;
use Magento\SalesRule\Api\Data\RuleInterface;
use Magento\SalesRule\Api\Data\CouponInterface;
use Magento\Framework\Exception\InputException;
use Magento\SalesRule\Api\RuleRepositoryInterface;
use Magento\Framework\Exception\LocalizedException;
use Magento\SalesRule\Api\CouponRepositoryInterface;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\SalesRule\Api\Data\RuleInterfaceFactory;
use Magento\Framework\Controller\ResultFactory;
use \Magento\Framework\Controller\Result\JsonFactory;


class Coupon extends Action
{
    /**
     * @var LoggerInterface
     */
    private $logger;

    /**
     * @var CouponRepositoryInterface
     */
    protected $couponRepository;

    /**
     * @var RuleRepositoryInterface
     */
    protected $ruleRepository;

    /**
     * @var Rule
     */
    protected $rule;

    /**
     * @var CouponInterface
     */
    protected $coupon;
    
    /**
     * @var SaleRuleInterface
     */
    protected $saleRule;    
    
    /**
     * @var \Magento\Framework\Controller\Result\JsonFactory
     */
    private $jsonResultFactory;


    public function __construct(
        CouponRepositoryInterface $couponRepository,
        RuleRepositoryInterface $ruleRepository,
        RuleInterfaceFactory $rule,
        CouponInterface $coupon,
        LoggerInterface $logger,
        \Magento\SalesRule\Model\Rule $saleRule,
        \Magento\SalesRule\Model\ResourceModel\Rule\CollectionFactory  $collection,
        \Magento\Framework\Stdlib\DateTime\Timezone $_stdTimezone,
        JsonFactory $jsonResultFactory,
        Context $context)
        
    {
        parent::__construct($context);
    
        $this->couponRepository = $couponRepository;
        $this->ruleRepository = $ruleRepository;
        $this->rule = $rule;
        $this->coupon = $coupon;
        $this->logger = $logger;
        $this->saleRule = $saleRule;
        $this->collection = $collection;
        $this->_stdTimezone = $_stdTimezone;
        $this->jsonResultFactory = $jsonResultFactory;
    }
    
    public function execute()
    {
        $responce = $this->createRule();
        $data = ['success' => $responce['status'], 'percent' => $responce['discount'], 'msg' => $responce['responce']];
        $result = $this->jsonResultFactory->create();
        $result->setData($data);
         return $result;
    }

    public function createRule()
    {
        reexecute:
        $random = rand(1, 5) * 10;
        if($random == 50){
            $currentDate = $this->_stdTimezone->date()->format('Y-m-d');
            $rules = $this->collection->create()
                        ->addFieldToFilter('is_active', 1)
                        ->addFieldToFilter('from_date', ['eq' => $currentDate])
                        ->addFieldToFilter('discount_amount', 50);
            $count = 1;
        
         foreach ($rules as $rule) {
            if ($count > 10) {
                goto reexecute;
                  }
                $count++;
            }
        }

        $newRule = $this->rule->create();
        $newRule->setName('10-50% Discount Mystry')
            ->setDescription("10-50% Discount Mystry Rule")
            ->setIsAdvanced(true)
            ->setStopRulesProcessing(false)
            ->setDiscountQty($random)
            ->setCustomerGroupIds([0, 1, 2, 3, 4, 5, 6, 7, 8, 10])
            ->setWebsiteIds([1])
            ->setIsRss(0)
            ->setUsesPerCoupon(1)
            ->setDiscountStep(0)
            ->setCouponType(RuleInterface::COUPON_TYPE_SPECIFIC_COUPON)
            ->setSimpleAction(RuleInterface::DISCOUNT_ACTION_FIXED_AMOUNT_FOR_CART)
            ->setDiscountAmount($random)
            ->setIsActive(true)
            ->setFromDate(date('Y-m-d'));

        try {
            $ruleCreate = $this->ruleRepository->save($newRule);

            //If rule generated, Create new Coupon by rule id
            if ($ruleCreate->getRuleId()) {
                $couponCode = 'P' . $this->generateRandomString() . 'C' . $this->generateRandomString(3) . $this->generateRandomString(4);
                $this->createCoupon($ruleCreate->getRuleId(), $couponCode);

                return array('status' => 1, 'discount' => $random, 'responce' => $couponCode);
            }
        } catch (Exception $exception) {
            $this->logger->error($exception->getMessage());
            return array('status' => 0, 'discount' => $random, 'responce' => $exception->getMessage());

        }
        return array('status' => 0, 'discount' => $random, 'responce' => "Coupon Code not Generated");

        
    }

     public function generateRandomString($length = 12) {
        $characters = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $randomString = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[random_int(0, strlen($characters) - 1)];
        }
        return $randomString;
    }
   

    public function createCoupon(int $ruleId, $couponCode) {
        /** @var CouponInterface $coupon */

        $coupon = $this->coupon;
    
        $coupon->setCode($couponCode)
            ->setIsPrimary(1)
            ->setRuleId($ruleId);
    
        /** @var CouponRepositoryInterface $couponRepository */
        $couponRepository = $this->couponRepository;

        $couponRepository->save($coupon);

        return $coupon->getCouponId();
    }

}