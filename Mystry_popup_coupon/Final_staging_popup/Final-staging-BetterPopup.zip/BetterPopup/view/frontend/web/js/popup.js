/**
 * 
 * 
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_BetterPopup
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

define([
    'jquery',
    'fireworks',
    'bioEp',
    'jquery-ui-modules/widget'
], function ($, firework) {
    'use strict';

    $.widget('mageplaza.betterpopup_block', {
        options: {
            dataPopup: {}
        },

        _create: function () {
            this._showPopup();
            this._clickTrigger();
            this._clickClose();
            this._clickSuccess();
            
            if (this._checkUpdateTemplate()) {
                if ($('#mp-popup-template5').length) {
                    $('#bio_ep_close').css({'top': '-100px'});
                    $('#bio_ep_close img').attr('src', this.options.dataPopup.srcCloseIconWhite);
                }
            }

        },

        _showPopup: function () {
            var self = this,
                popupElem = $('.mageplaza-betterpopup-block').length,
                triggerElem = $('.mp-better-popup-click-trigger');
            this._createStyleTag();
            this._removeDuplicatePopup();

            //Check show trigger
            if (this.options.dataPopup.afterSeconds.isAfterSeconds) {
                setTimeout(function () {
                    triggerElem.show();
                    self._setDefaultSize();
                }, this.options.dataPopup.afterSeconds.delay * 1000);
            } else {
                triggerElem.show();
                self._setDefaultSize();
            }

            if (popupElem <= 1) {
                if (this.options.dataPopup.isScroll) {  // show when scroll
                    self._scrollToShow();
                    self._setDefaultSize();
                } else if (this.options.dataPopup.isExitIntent) { //show when Exit Intent
                    $(document).mouseleave(function () {
                        bioEp.init(self.options.dataPopup.popupConfig);
                        self._fullScreen();
                        $(document).off('mouseleave');
                        self._setDefaultSize();
                    });
                } else {
                    bioEp.init(self.options.dataPopup.popupConfig);

                    if (this.options.dataPopup.fullScreen.isFullScreen) {
                        self._setDefaultSize();
                    }
                    self._fullScreen();
                }

            }
        },

        /**
         * Event click float button to show popup
         * @private
         */
        _clickTrigger: function () {
            var self = this;

            $('.mp-better-popup-click-trigger').click(function () {
                var bgEl = $('#bio_ep_bg');
                if (!bgEl.length) {
                    $('body').append("<div id='bio_ep_bg'></div>");
                    self._fullScreen();
                }

                bioEp.init(self.options.dataPopup.popupConfig);
                self._scrollToShow();
                $('#bio_ep').show();
                $('#bio_ep_bg').show();
                $('#bio_ep_close').show();
                $('#mp-newsletter-error').hide();
                $('#mp-newsletter').css('border-color', '#c2c2c2');
                $('[id]').each(function () {
                    $('[id="bio_ep_bg"]:gt(0)').remove();
                });
            });
        },

        /**
         * Event click close popup button
         * @private
         */
        _clickClose: function () {
            $('#bio_ep_close').click(function () {
                $('#bio_ep').hide();
                $('#bio_ep_bg').hide();
                $('.btn-copy').text('Copy');
                $('canvas#screen').hide();
            })
        },

        
        /**
         * Event click success button
         * @private
         */
        _clickSuccess: function () {

            var self = this,
                bioContent = $('#bio_ep_content'),
                template4 = $('#mp-popup-template4').length, // check on template 4
                template5 = $('#mp-popup-template5').length, // check on template 5
                form = $('#mp-newsletter-validate-detail');

    
                
                    $(".btn-popup").click(function(e) {
                        console.log("Button clicked");
                            
                        $('#loader').show();

                        var url = 'betterpopup/index/coupon';

                        $.ajax({
                            url: url,
                            dataType: 'json',
                            type: 'POST',
                            success: function (data) {
                                $('#loader').hide(); // Hide the loader

                                if (!data.success) {
                                    $('#mp-newsletter-error').text(data.msg).show();
                                }
                                else{
                                    // $('#mp-coupon-code').show();    // Show the input box
                                    // $('.success-title').show();     // Show Msg thankyou 
                                    // $('#small').show();             // Show pls use this coupon
                                    // $('.btn-copy-msg').show();      // Show copy code button

                                    $('.success-step').show(); 
                                    $('.welcome-step').hide(); 


                                    // $('.btn-popup').hide();         // Hide Revel coupon code button
                                    // $('.subtitle').hide();          // Hide Greatness
                                    // $('.heading').hide();           // Hide Unlock
                                    // $('.third-font').hide();        // Hide sidewise
                                    $('#mp-newsletter-success').hide();
                                    $('#mp-coupon-code').val(data.msg);
                                    $('#discountPercentage').html(data.percent);
                                }
                            }
                        });

                     
                        //css for error message
                        if (!self._checkUpdateTemplate()) {
                            $('#mp-newsletter-error').css({"position": "absolute", "width": "100%"});
                        }
                
                        if (template4) {
                            $('#mp-newsletter-error').css({"position": "absolute", "bottom": "25px", "left": "35px"});
                        }
                
                        if (template5) {
                            $('.tmp5-msg-error').html('');
                            $("#mp-newsletter-error").appendTo(".tmp5-msg-error");
                        }
                    });
                },

            // form.submit(function (e) {
            //     $(".btn-popup").click(function(e) {
            //     if (form.validation('isValid')) {
            //         var email = $("#mp-newsletter").val(),
            //             // url = form.attr('action'),
            //             url = 'betterpopup/index/coupo',
            //             loader = $('.popup-loader');

            //         loader.show();
            //         if (template4) {
            //             $('.popup-loader').css({'left': '200px'});
            //         }
            //         e.preventDefault();
            //         $.ajax({
            //             url: url,
            //             dataType: 'json',
            //             type: 'POST',
            //             data: {email: email},
            //             success: function (data) {
            //                 loader.hide();
            //                 if (!data.success) {
            //                     $('#mp-newsletter-error').text(data.msg).show();
            //                 }
            //                 else{
            //                     $('#mp-newsletter-success').show();
            //                     $('#mp-coupon-code').val(data.msg);
            //                     $('#discountPercentage').html(data.percent);
            //                 }
            //             }
            //         });
            //     }

            //     //css for error message
            //     if (!self._checkUpdateTemplate()) {
            //         $('#mp-newsletter-error').css({"position": "absolute", "width": "100%"});
            //     }

            //     if (template4) {
            //         $('#mp-newsletter-error').css({"position": "absolute", "bottom": "25px", "left": "35px"});
            //     }

            //     if (template5) {
            //         $('.tmp5-msg-error').html('');
            //         $("#mp-newsletter-error").appendTo(".tmp5-msg-error");
            //     }
            // });
        // },

        /**
         * Scroll to show popup
         * @private
         */
        _scrollToShow: function () {
            var self = this;

            $(window).scroll(function () {
                var scrollTop = $(window).scrollTop(),
                    docHeight = $(document).height(),
                    winHeight = $(window).height(),
                    scrollPercent = (scrollTop) / (docHeight - winHeight),
                    optionScroll = self.options.dataPopup.percentage / 100;

                if ((scrollPercent >= optionScroll) || (scrollPercent > 0.9)) {
                    bioEp.init(self.options.dataPopup.popupConfig);
                    self._fullScreen();
                    $(window).off('scroll');
                }
            });
        },

        /**
         * Css for full creen option
         * @private
         */
        _fullScreen: function () {
            if (this.options.dataPopup.fullScreen.isFullScreen) {
                $('#bio_ep_bg').css({'background-color': this.options.dataPopup.fullScreen.bgColor, 'opacity': 1});
            }
        },

        /**
         * Remove duplicate popup
         * @private
         */
        _removeDuplicatePopup: function () {
            $('[id]').each(function () {
                $('[id="mageplaza-betterpopup-block"]:gt(0)').remove();
            });
        },

        /**
         * Create Style tag on head
         * @private
         */
        _createStyleTag: function () {
            var head = document.head,
                style = document.createElement('style');

            style.type = 'text/css';
            head.appendChild(style);
        },

        _checkUpdateTemplate: function () {
            return !!($('#mp-popup-template3').length || $('#mp-popup-template4').length || $('#mp-popup-template5').length || $('#mp-popup-template6').length);
        },

        _setDefaultSize: function() {
            if (this.options.dataPopup.popupConfig.width === null
                || this.options.dataPopup.popupConfig.height === null) {
                if ($('#mp-popup-template3').length) {
                    $('#bio_ep').css({"width": "800px", "height": "321px"});
                } else if ($('#mp-popup-template4').length) {
                    $('#bio_ep').css({"width": "605px", "height": "330px"});
                } else if ($('#mp-popup-template5').length) {
                    $('#bio_ep').css({"width": "359px", "height": "260px"});
                } else if ($('#mp-popup-template6').length) {
                    $('#bio_ep').css({"width": "800px", "height": "250px"});
                }
            }
        }
    
    });

    return $.mageplaza.betterpopup_block;
});



