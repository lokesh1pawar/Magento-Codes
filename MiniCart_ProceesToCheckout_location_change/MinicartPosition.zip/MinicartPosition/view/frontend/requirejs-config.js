var config = {
    config: {
        mixins: {
            'Magento_Checkout/js/view/minicart': {
                'Lokesh_MinicartPosition/js/view/minicart-mixin': true
            }
        }
    }
};