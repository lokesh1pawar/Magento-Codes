<?php

namespace Plumtree\TrackingPixel\Block;

use \Magento\Framework\View\Element\Template;
use \Plumtree\TrackingPixel\Helper\Data;
use \Magento\Framework\Registry;

class SocialCatalog extends Template
{
    /**
     * @var Helper
     */
    private $helper;

    /**
     * @var Registry
     */
    protected $registry;
    
    /**
     * @param Helper $helper
     * @param Registry $registry
     * @param array $data
     */
    public function __construct(
        Template\Context $context,
        Data $helper,
        Registry $registry,
        array $data = []
    ) {
        $this->helper = $helper;
        $this->registry = $registry;
        parent::__construct($context, $data);
    }

    /**
     * @return string
     */
    public function getFacebookPixelIdEnable()
    {
        return $this->helper->getFacebookPixelEnable();
    }

    public function getCurrentProduct()
    {       
        return $this->registry->registry('current_product');
    }
}
