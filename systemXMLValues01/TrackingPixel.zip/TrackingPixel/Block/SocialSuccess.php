<?php

namespace Plumtree\TrackingPixel\Block;

use \Magento\Framework\View\Element\Template;
use \Plumtree\TrackingPixel\Helper\Data;
use \Magento\Sales\Model\OrderFactory;
use \Magento\Checkout\Model\Session;

class SocialSuccess extends Template
{
    /**
     * @var Helper
     */
    private $helper;

    /**
     * @var \Magento\Sales\Model\OrderFactory
     */
    protected $_orderFactory;

    /**
     * @var Session
     */
    protected $session;
    
    /**
     * @param Helper $helper
     * @param Order $order
     * @param Session $session
     * @param array $data
     */
    public function __construct(
        Template\Context $context,
        Data $helper,
        \Magento\Sales\Model\OrderFactory $orderFactory,
        Session $session,
        array $data = []
    ) {
        $this->helper = $helper;       
        $this->_orderFactory = $orderFactory;
        $this->session = $session;
        parent::__construct($context, $data);
    }

    /**
    * Retrieve current order
    *
    * @return \Magento\Sales\Model\Order
    */
    public function getOrderSubtotal()
    {
       $orderId = $this->session->getLastOrderId();
       $order   = $this->_orderFactory->create()->load($orderId);
       return $order->getSubtotal(); // you can access various order details from here. 
    }

    /**
     * @return string
     */
    public function getGoogleAdsIdEnable()
    {
        return $this->helper->getGoogleAdsEnable();
    }

    /**
     * @return string
     */
    public function getGoogleAdsId()
    {
        return $this->helper->getGoogleAds();
    }

    /**
     * @return string
     */
    public function getFacebookPixelIdEnable()
    {
        return $this->helper->getFacebookPixelEnable();
    }

    /**
     * @return string
     */
    public function getOrderNumber()
    {
        $order = $this->session->getLastRealOrder();
        return $order->getIncrementId();
    }

    /**
     * @return string
     */
    public function getGoogleSendToId()
    {
        return $this->helper->getGoogleSendToId();
    }

    /**
     * @return string
     */
    public function getBingEnable()
    {
        return $this->helper->getBingSnippetEnable();
    }
}
