<?php

namespace Plumtree\TrackingPixel\Block;

use \Magento\Framework\View\Element\Template;
use \Plumtree\TrackingPixel\Helper\Data;

class SocialHeader extends Template
{
    /**
     * @var Helper
     */
    private $helper;
    
    /**
     * @param Template\Context $context
     * @param Helper $helper
     * @param array $data
     */
    public function __construct(
        Template\Context $context,
        Data $helper,
        array $data = []
    ) {
        $this->helper = $helper;
        parent::__construct($context, $data);
    }

    /**
     * @return string
     */
    public function getGoogleAdsIdEnable()
    {
        return $this->helper->getGoogleAdsEnable();
    }

    /**
     * @return string
     */
    public function getGoogleAdsId()
    {
        return $this->helper->getGoogleAds();
    }

    /**
     * @return string
     */
    public function getFacebookPixelIdEnable()
    {
        return $this->helper->getFacebookPixelEnable();
    }

    /**
     * @return string
     */
    public function getFacebookPixelId()
    {
        return $this->helper->getFacebookPixel();
    }

    /**
     * @return string
     */
    public function getBingEnable()
    {
        return $this->helper->getBingSnippetEnable();
    }

    /**
     * @return string
     */
    public function getBingId()
    {
        return $this->helper->getBingId();
    }
}
