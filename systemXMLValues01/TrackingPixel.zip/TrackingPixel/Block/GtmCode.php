<?php

namespace Plumtree\TrackingPixel\Block;

use \Magento\Framework\View\Element\Template;
use \Plumtree\TrackingPixel\Helper\Data;

class GtmCode extends Template
{
    /**
     * @var Helper
     */
    private $helper;
    
    /**
     * @param Template\Context $context
     * @param Helper $helper
     * @param array $data
     */
    public function __construct(
        Template\Context $context,
        Data $helper,
        array $data = []
    ) {
        $this->helper = $helper;
        parent::__construct($context, $data);
    }

    /**
     * @return string
     */
    public function getGtmStatus()
    {
        return $this->helper->getGtmStatus();
    }

    /**
     * @return string
     */
    public function getGtmId()
    {
        return $this->helper->getGtmId();
    }
}
