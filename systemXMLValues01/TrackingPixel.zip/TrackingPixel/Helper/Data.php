<?php

namespace Plumtree\TrackingPixel\Helper;

use Magento\Framework\App\Helper\AbstractHelper;
use \Magento\Framework\App\Helper\Context;
use \Magento\Framework\App\Config\ScopeConfigInterface;

class Data extends AbstractHelper
{
    const XML_PATH_SOCIAL_GOOGLE_ADS_ENABLE = 'social_code/social_data/enable_googleads';

    const XML_PATH_SOCIAL_GOOGLE_ADS = 'social_code/social_data/google_ads';

    const XML_PATH_SOCIAL_GOOGLE_SEND_TO_ID = 'social_code/social_data/google_send_to_id';

    const XML_PATH_SOCIAL_FACEBOOK_PXL_ENABLE = 'social_code/social_data/enable_facebookpixel';

    const XML_PATH_SOCIAL_FACEBOOK_PXL = 'social_code/social_data/facebook_pixel';

    const XML_PATH_SOCIAL_BING_ENABLE = 'social_code/social_data/enable_bing';

    const XML_PATH_SOCIAL_BING_ID = 'social_code/social_data/bing_id';
	const XML_PATH_GTM_STATUS = 'social_code/gtm/status';
	const XML_PATH_GTM_ID = 'social_code/gtm/id';

    /**
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    protected $scopeConfig;

    /**
     * @param Context $context
     * @param ScopeConfigInterface $scopeConfig
     */
    public function __construct(
        Context $context,
        ScopeConfigInterface $scopeConfig
    ) {
        parent::__construct($context);
        $this->scopeConfig = $scopeConfig;        
    }


    /**
     * @return string
     */
    public function getGoogleAdsEnable()
    {
        return $this->scopeConfig->getValue(
            self::XML_PATH_SOCIAL_GOOGLE_ADS_ENABLE,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }

    /**
     * @return string
     */
    public function getGoogleAds()
    {
        return $this->scopeConfig->getValue(
            self::XML_PATH_SOCIAL_GOOGLE_ADS,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }

    /**
     * @return string
     */
    public function getFacebookPixelEnable()
    {
        return $this->scopeConfig->getValue(
            self::XML_PATH_SOCIAL_FACEBOOK_PXL_ENABLE,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }

    /**
     * @return string
     */
    public function getFacebookPixel()
    {
        return $this->scopeConfig->getValue(
            self::XML_PATH_SOCIAL_FACEBOOK_PXL,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }

    /**
     * @return string
     */
    public function getGoogleSendToId()
    {
        return $this->scopeConfig->getValue(
            self::XML_PATH_SOCIAL_GOOGLE_SEND_TO_ID,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }

    /**
     * @return string
     */
    public function getBingSnippetEnable()
    {
        return $this->scopeConfig->getValue(
            self::XML_PATH_SOCIAL_BING_ENABLE,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }

    /**
     * @return string
     */
    public function getBingId()
    {
        return $this->scopeConfig->getValue(
            self::XML_PATH_SOCIAL_BING_ID,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }
    /**
     * @return string
     */
    public function getGtmStatus()
    {
        return $this->scopeConfig->getValue(
            self::XML_PATH_GTM_STATUS,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }

    /**
     * @return string
     */
    public function getGtmId()
    {
        return $this->scopeConfig->getValue(
            self::XML_PATH_GTM_ID,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }

}
