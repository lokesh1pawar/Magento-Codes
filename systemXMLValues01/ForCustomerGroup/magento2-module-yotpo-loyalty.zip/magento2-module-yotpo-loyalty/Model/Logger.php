<?php
namespace Yotpo\Loyalty\Model;

class Logger extends \Monolog\Logger
{
}
