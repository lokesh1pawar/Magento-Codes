<?php

namespace Yotpo\Loyalty\Block;

class Snippet extends \Yotpo\Loyalty\Block\AbstractBlock
{
}
