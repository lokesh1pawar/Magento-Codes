<?php

namespace Yotpo\Loyalty\Api\Swell\Session;

interface RemoveCodeManagementInterface
{

    /**
     * POST for RemoveCode api
     * @return string
     */
    public function postRemoveCode();
}
