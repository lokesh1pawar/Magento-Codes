<?php

namespace Yotpo\Loyalty\Api\Swell\Session;

interface SnippetManagementInterface
{

    /**
     * GET for Snippet api
     * @return string
     */
    public function getSnippet();
}
