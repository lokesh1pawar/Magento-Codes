<?php

namespace Yotpo\Loyalty\Api\Swell\Session;

interface CouponManagementInterface
{

    /**
     * POST for Coupon api
     * @return string
     */
    public function postCoupon();
}
