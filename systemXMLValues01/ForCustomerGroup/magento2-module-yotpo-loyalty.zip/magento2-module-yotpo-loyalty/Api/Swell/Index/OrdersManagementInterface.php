<?php

namespace Yotpo\Loyalty\Api\Swell\Index;

interface OrdersManagementInterface
{

    /**
     * GET for Orders api
     * @return string
     */
    public function getOrders();
}
