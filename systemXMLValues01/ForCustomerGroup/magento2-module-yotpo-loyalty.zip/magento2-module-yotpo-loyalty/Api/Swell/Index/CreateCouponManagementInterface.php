<?php

namespace Yotpo\Loyalty\Api\Swell\Index;

interface CreateCouponManagementInterface
{

    /**
     * POST for CreateCoupon api
     * @return string
     */
    public function postCreateCoupon();
}
