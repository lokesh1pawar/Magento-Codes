<?php

namespace Yotpo\Loyalty\Api\Swell\Index;

interface DeleteCouponManagementInterface
{

    /**
     * POST for DeleteCoupon api
     * @return string
     */
    public function postDeleteCoupon();
}
