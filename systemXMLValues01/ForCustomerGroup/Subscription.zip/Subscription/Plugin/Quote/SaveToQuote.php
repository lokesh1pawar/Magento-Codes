<?php


namespace Echidna\Subscription\Plugin\Quote;

use Magento\Quote\Model\QuoteRepository;
use phpDocumentor\Reflection\Types\This;

class SaveToQuote
{
    /** @var QuoteRepository */
    protected $quoteRepository;
    protected $_checkoutSession;

    /**
     * ShippingInformationManagement constructor.
     * @param QuoteRepository $quoteRepository
     */
    public function __construct(
        QuoteRepository $quoteRepository,
        \Magento\Checkout\Model\Session $checkoutSession
    )
    {
        $this->_checkoutSession = $checkoutSession;
        $this->quoteRepository = $quoteRepository;
    }

    public function beforeSaveAddressInformation(
        \Magento\Checkout\Model\ShippingInformationManagement $subject,
        $cartId,
        \Magento\Checkout\Api\Data\ShippingInformationInterface $addressInformation
    )
    {
        if (!$extAttributes = $addressInformation->getExtensionAttributes()) {
            return;
        }
        if ($extAttributes->getSubscriptionName() !== "" && $extAttributes->getStartDate() !== "") {
            $this->_checkoutSession
                ->setSubscriptionName($extAttributes->getSubscriptionName())
                ->setStartDate($extAttributes->getStartDate())
                ->setEndDate($extAttributes->getEndDate())
                ->setFrequency($extAttributes->getFrequency())
                ->setDay($extAttributes->getDaysCheckbox());
        } else {
            $this->_checkoutSession
                ->unsSubscriptionName()
                ->unsStartDate()
                ->unsEndDate()
                ->unsFrequency()
                ->unsDay();
        }
        if ($extAttributes->getDob() != null) {
            $this->_checkoutSession->setDob($extAttributes->getDob());
        }else{
            $this->_checkoutSession->unsDob();
        }
    }
}
