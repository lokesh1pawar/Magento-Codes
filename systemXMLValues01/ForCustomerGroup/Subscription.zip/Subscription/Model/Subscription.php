<?php


namespace Echidna\Subscription\Model;

use Echidna\Subscription\Api\Data\SubscriptionInterface;

class Subscription extends \Magento\Framework\Model\AbstractModel implements SubscriptionInterface
{
    /**
     * CMS page cache tag.
     */
    const CACHE_TAG = 'subscription';

    /**
     * @var string
     */
    protected $_cacheTag = 'subscription';

    /**
     * Prefix of model events names.
     *
     * @var string
     */
    protected $_eventPrefix = 'subscription';

    /**
     * Initialize resource model.
     */
    protected function _construct()
    {
        $this->_init('Echidna\Subscription\Model\ResourceModel\Subscription');
    }
    public function getEntityId()
    {
        return $this->getData(self::ENTITY_ID);
    }

    /**
     * Set EntityId.
     */
    public function setEntityId($entityId)
    {
        return $this->setData(self::ENTITY_ID, $entityId);
    }

    public function getOrderId()
    {
        return $this->getData(self::ORDER_ID);
    }

    public function setOrderId($orderId)
    {
        return $this->setData(self::ORDER_ID, $orderId);
    }

    public function getSubscriptionName()
    {
        return $this->getData(self::SUBSCRIPTION_NAME);
    }

    public function setSubscriptionName($subscriptionName)
    {
        return $this->setData(self::SUBSCRIPTION_NAME, $subscriptionName);
    }

    public function getFrequency()
    {
        return $this->getData(self::FREQUENCY);
    }

    public function setFrequency($frequency)
    {
        return $this->setData(self::FREQUENCY, $frequency);
    }

    public function getDay()
    {
        return $this->getData(self::DAY);
    }

    public function setDay($day)
    {
        return $this->setData(self::DAY, $day);
    }

    public function getStartDate()
    {
        return $this->getData(self::START_DATE);
    }

    public function setStartDate($startDate)
    {
        return $this->setData(self::START_DATE, $startDate);
    }

    public function getEndDate()
    {
        return $this->getData(self::END_DATE);
    }

    public function setEndDate($endDate)
    {
        return $this->setData(self::END_DATE, $endDate);
    }
}
