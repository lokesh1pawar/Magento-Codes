<?php


namespace Echidna\Subscription\Model;

use Echidna\Subscription\Api\Data\SubscriptionInterface;
use Echidna\Subscription\Api\Data\SubscriptionSearchResultInterfaceFactory;
use Echidna\Subscription\Api\SubscriptionRepositoryInterface;
use Echidna\Subscription\Model\SubscriptionFactory;
use Echidna\Subscription\Model\ResourceModel\Subscription\CollectionFactory as SubscriptionCollectionFactory;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Api\SearchCriteriaInterface;

/**
 * Class SubscriptionRepository
 * @package Echidna\Subscription\Model
 */
class SubscriptionRepository implements SubscriptionRepositoryInterface
{
    /**
     * @var SubscriptionFactory
     */
    private $subscriptionFactory;

    /**
     * @var SubscriptionCollectionFactory
     */
    private $subscriptionCollectionFactory;

    /**
     * @var SubscriptionSearchResultInterfaceFactory
     */
    private $searchResultFactory;
    /**
     * @var CollectionProcessorInterface
     */
    private $collectionProcessor;

    /**
     * SubscriptionRepository constructor.
     * @param SubscriptionFactory $subscriptionFactory
     * @param SubscriptionCollectionFactory $subscriptionCollectionFactory
     * @param SubscriptionSearchResultInterfaceFactory $subscriptionSearchResultInterfaceFactory
     * @param CollectionProcessorInterface $collectionProcessor
     */
    public function __construct(
        SubscriptionFactory $subscriptionFactory,
        SubscriptionCollectionFactory $subscriptionCollectionFactory,
        SubscriptionSearchResultInterfaceFactory $subscriptionSearchResultInterfaceFactory,
        CollectionProcessorInterface $collectionProcessor
    )
    {
        $this->subscriptionFactory = $subscriptionFactory;
        $this->subscriptionCollectionFactory = $subscriptionCollectionFactory;
        $this->searchResultFactory = $subscriptionSearchResultInterfaceFactory;
        $this->collectionProcessor = $collectionProcessor;
    }

    // ... getById, save and delete methods listed above ...

    public function getList(SearchCriteriaInterface $searchCriteria)
    {
        $collection = $this->subscriptionCollectionFactory->create();
        $this->collectionProcessor->process($searchCriteria, $collection);
        $searchResults = $this->searchResultFactory->create();

        $searchResults->setSearchCriteria($searchCriteria);
        $searchResults->setItems($collection->getItems());

        return $searchResults;
    }

    public function getById($id)
    {
        return $this->getById($id);
    }

    public function save(SubscriptionInterface $subscription)
    {
        return $this->save($subscription);
    }

    public function delete(SubscriptionInterface $subscription)
    {
        return $this->delete($subscription);
    }
}
