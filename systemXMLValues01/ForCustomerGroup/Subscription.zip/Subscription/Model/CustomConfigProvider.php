<?php


namespace Echidna\Subscription\Model;

use Magento\Checkout\Model\ConfigProviderInterface;

class CustomConfigProvider implements ConfigProviderInterface
{
    protected $checkoutSession;
    protected $helperData;

    public function __construct(
        \Magento\Checkout\Model\Session $checkoutSession,
        \Echidna\Subscription\Helper\Data $helperData
    )
    {
        $this->helperData = $helperData;
        $this->checkoutSession = $checkoutSession;
    }

    public function getConfig()
    {
        $config = [];
        if (!$this->checkoutSession->getSubscriptionName()) {
            $config['subscription'] = null;
        } else {
            $config['subscription'] = [
                'subscription_name' => $this->checkoutSession->getSubscriptionName(),
                'start_date' => $this->checkoutSession->getStartDate(),
                'end_date' => $this->checkoutSession->getEndDate(),
                'frequency' => $this->checkoutSession->getFrequency(),
                'day' => $this->checkoutSession->getDay()
            ];
        }
        $config['frequency'] = $this->helperData->getFrequency();
        $config['days'] = $this->helperData->getDays();
        return $config;
    }
}
