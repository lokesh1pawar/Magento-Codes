<?php


namespace Echidna\Subscription\Model\Config\Source;


class Frequency implements \Magento\Framework\Data\OptionSourceInterface
{

    const CRON_YEARLY = 'Yearly';

    const CRON_MONTHLY = 'Monthly';

    const CRON_WEEKLY = 'Weekly';

    /**
     * @return array
     */
    public function toOptionArray()
    {
        return [
                ['label' => __('Yearly'), 'value' => self::CRON_YEARLY],
                ['label' => __('Monthly'), 'value' => self::CRON_MONTHLY],
                ['label' => __('Weekly'), 'value' => self::CRON_WEEKLY],
            ];
    }
}
