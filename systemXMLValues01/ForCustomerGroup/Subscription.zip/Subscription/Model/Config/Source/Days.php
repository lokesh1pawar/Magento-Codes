<?php


namespace Echidna\Subscription\Model\Config\Source;


class Days implements \Magento\Framework\Data\OptionSourceInterface
{

    const SUNDAY = 'Sunday';
    const MONDAY = 'Monday';
    const TUESDAY = 'Tuesday';
    const WEDNESDAY = 'Wednesday';
    const THURSDAY = 'Thursday';
    const FRIDAY = 'Friday';
    const SATURDAY = 'Saturday';

    /**
     * @return array
     */
    public function toOptionArray()
    {
        return [
            ['label' => __(self::SUNDAY), 'value' => self::SUNDAY],
            ['label' => __(self::MONDAY), 'value' => self::MONDAY],
            ['label' => __(self::TUESDAY), 'value' => self::TUESDAY],
            ['label' => __(self::WEDNESDAY), 'value' => self::WEDNESDAY],
            ['label' => __(self::THURSDAY), 'value' => self::THURSDAY],
            ['label' => __(self::FRIDAY), 'value' => self::FRIDAY],
            ['label' => __(self::SATURDAY), 'value' => self::SATURDAY],
        ];
    }
}
