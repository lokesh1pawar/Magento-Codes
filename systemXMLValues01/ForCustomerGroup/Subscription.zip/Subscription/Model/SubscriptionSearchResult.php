<?php


namespace Echidna\Subscription\Model;

use Magento\Framework\Api\SearchResults;
use Echidna\Subscription\Api\Data\SubscriptionSearchResultInterface;

class SubscriptionSearchResult extends SearchResults implements SubscriptionSearchResultInterface
{

}
