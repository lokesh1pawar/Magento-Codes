<?php


namespace Echidna\Subscription\Model\ResourceModel\Subscription;


class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    /**
     * @var string
     */
    protected $_idFieldName = 'entity_id';
    protected $_eventPrefix = 'subscription_collection';
    protected $_eventObject = 'subscription_collection';
    /**
     * Define resource model.
     */
    protected function _construct()
    {
        $this->_init('Echidna\Subscription\Model\Subscription', 'Echidna\Subscription\Model\ResourceModel\Subscription');
    }
}
