<?php


namespace Echidna\Subscription\Api;

use Magento\Framework\Api\SearchCriteriaInterface;
use Echidna\Subscription\Api\Data\SubscriptionInterface;
interface SubscriptionRepositoryInterface
{
    /**
     * @param $id
     * @return mixed
     */
    public function getById($id);

    /**
     * @param SubscriptionInterface $amasty
     * @return mixed
     */
    public function save(SubscriptionInterface $subscription);

    /**
     * @param SubscriptionInterface $subscription
     * @return mixed
     */
    public function delete(SubscriptionInterface $subscription);

    /**
     * @param SearchCriteriaInterface $searchCriteria
     * @return mixed
     */
    public function getList(SearchCriteriaInterface $searchCriteria);
}
