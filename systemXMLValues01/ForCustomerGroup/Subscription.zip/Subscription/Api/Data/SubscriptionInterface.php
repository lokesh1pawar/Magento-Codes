<?php


namespace Echidna\Subscription\Api\Data;

interface SubscriptionInterface
{
    const ENTITY_ID = 'entity_id';
    const ORDER_ID = 'order_id';
    const SUBSCRIPTION_NAME = 'subscription_name';
    const FREQUENCY = 'frequency';
    const DAY = 'day';
    const START_DATE = 'start_date';
    const END_DATE = 'end_date';

    /**
     * @return mixed
     */
    public function getEntityId();

    /**
     * Set EntityId.
     */
    public function setEntityId($entityId);

    /**
     * @return mixed
     */
    public function getOrderId();

    /**
     * Set Order Id.
     */
    public function setOrderId($orderId);

    /**
     * @return mixed
     */
    public function getSubscriptionName();

    /**
     * @param $subscriptionName
     * @return mixed
     */
    public function setSubscriptionName($subscriptionName);

    /**
     * @return mixed
     */
    public function getFrequency();

    /**
     * Set Frequency.
     */
    public function setFrequency($frequency);

    /**
     * @return mixed
     */
    public function getDay();

    /**
     * Set Day.
     */
    public function setDay($day);

    /**
     * @return mixed
     */
    public function getStartDate();

    /**
     * Set StartDate.
     */
    public function setStartDate($startDate);

    /**
     * @return mixed
     */
    public function getEndDate();

    /**
     * Set EndDate.
     */
    public function setEndDate($endDate);
}
