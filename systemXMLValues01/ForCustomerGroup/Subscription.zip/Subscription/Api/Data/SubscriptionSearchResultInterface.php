<?php


namespace Echidna\Subscription\Api\Data;

use Magento\Framework\Api\SearchResultsInterface;
interface SubscriptionSearchResultInterface extends SearchResultsInterface
{
    /**
     * @return \Echidna\Subscription\Api\Data\SubscriptionInterface[]
     */
    public function getItems();

    /**
     * @param \Echidna\Subscription\Api\Data\SubscriptionInterface[] $items
     * @return void
     */
    public function setItems(array $items);
}
