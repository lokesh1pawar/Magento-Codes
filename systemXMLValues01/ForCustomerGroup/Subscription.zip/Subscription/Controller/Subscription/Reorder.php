<?php


namespace Echidna\Subscription\Controller\Subscription;


use Magento\Checkout\Model\Session as CheckoutSession;
use Magento\Framework\App\ObjectManager;
use Magento\Framework\Exception\LocalizedException;

class Reorder extends \Magento\Framework\App\Action\Action
{

    protected $orderFactory;
    /**
     * @var \Magento\Sales\Model\Reorder\Reorder
     */
    private $reorder;
    protected $customerModel;
    protected $customerSession;

    /**
     * @var CheckoutSession
     */
    private $checkoutSession;

    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Sales\Model\OrderFactory $orderFactory,
        \Magento\Quote\Model\QuoteFactory $quoteFactory,
        \Magento\Sales\Model\Reorder\Reorder $reorder = null,
        CheckoutSession $checkoutSession = null,
        \Magento\Customer\Model\CustomerFactory $customerModel,
        \Magento\Customer\Model\Session $customerSession
    )
    {
        $this->customerModel = $customerModel;
        $this->customerSession = $customerSession;
        $this->orderFactory = $orderFactory;
        $this->reorder = $reorder ?: ObjectManager::getInstance()->get(\Magento\Sales\Model\Reorder\Reorder::class);
        $this->checkoutSession = $checkoutSession ?: ObjectManager::getInstance()->get(CheckoutSession::class);
        return parent::__construct($context);
    }

    public function execute()
    {
        $orderId = $this->getRequest()->getParam('id');
        $order = $this->orderFactory->create()->load($orderId);

        /** @var \Magento\Framework\Controller\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();

        if (!$this->customerSession->isLoggedIn()) {
            $customer = $this->customerModel->create()->load($order->getCustomerId());
            $this->customerSession->setCustomerAsLoggedIn($customer);
        }

        try {
            $reorderOutput = $this->reorder->execute($order->getIncrementId(), $order->getStoreId());
        } catch (LocalizedException $localizedException) {
            $this->messageManager->addErrorMessage($localizedException->getMessage());
            return $resultRedirect->setPath('checkout/cart');
        }
        $this->checkoutSession->setQuoteId($reorderOutput->getCart()->getId());

        $errors = $reorderOutput->getErrors();
        if (!empty($errors)) {
            $useNotice = $this->_objectManager->get(\Magento\Checkout\Model\Session::class)->getUseNotice(true);
            foreach ($errors as $error) {
                $useNotice
                    ? $this->messageManager->addNoticeMessage($error->getMessage())
                    : $this->messageManager->addErrorMessage($error->getMessage());
            }
        }
        return $resultRedirect->setPath('checkout/cart');
    }
}
