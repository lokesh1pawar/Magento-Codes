define([
    'jquery',
    'ko',
    'uiComponent',
    'Magento_Checkout/js/checkout-data',
    'Magento_Checkout/js/model/quote',
    'Magento_Customer/js/model/customer'
], function ($, ko, Component, checkoutData, quote, customer) {
    'use strict';

    return Component.extend({
        defaults: {
            template: 'Echidna_Subscription/subscription',
            showFormChecked : false,
            listens: {
                showFormChecked:'showFormCheckedF',
            },
            isDisplayWeekly: false,
            isCheckboxCheck: false
        },
        isCustomerLoggedIn: customer.isLoggedIn,
        initialize: function (config) {
            this.instoreShipping = ko.observable(false);
            this.clickCheckbox();
            return this._super(config);
        },

        clickCheckbox: function (){
            $(document).on('click','input[name="days_checkbox"]', function (){
                $('input[name="days_checkbox"]').not(this).prop('checked', false);
            });
        },
        /**
         * Initializes observable properties of instance
         *
         * @returns {Object} Chainable.
         */
        initObservable: function () {
            this._super()
                .observe(['showFormChecked']);
            return this;
        },
        setInstoreShipping: function (value) {
            this.instoreShipping(value == true);
        },
        getconfigValue: function () {
            return window.valuesConfig;
        },
        getQuoteItem:function (){
            var shippable = true;
            $.each(window.checkoutConfig.quoteItemData, function (key, val) {
                if (val.product.type_id === "aw_event_ticket"){
                    shippable = false;
                }
            });
            return shippable;
        },
        getDetails: function () {
            this.datePicker();
            this.showSubscriptionForm();
            return window.checkoutConfig.frequency ? window.checkoutConfig.frequency : null
        },
        getDaysLabel: function () {
            return window.checkoutConfig.days ? window.checkoutConfig.days : null;
        },
        datePicker: function () {
            $("#start-date").datepicker({
                numberOfMonths: 1,
                minDate: new Date(),
                dateFormat:'mm/dd/yy',
                onSelect: function(selected) {
                    $("#end-date").datepicker("option","minDate", selected)
                }
            });
            $("#end-date").datepicker({
                numberOfMonths: 1,
                minDate: new Date(),
                dateFormat:'mm/dd/yy',
                onSelect: function(selected) {
                    $("#start-date").datepicker("option","maxDate", selected)
                }
            });
        },
        chnageOption: function (){
            var option = $('[name="frequency"] option:selected').val();
            if (option === 'Weekly'){
                $(".field.field-days").show();
            }else {
                $(".field.field-days").hide();
            }
        },
        showSubscriptionForm: function () {
            var value = $("#checkout-with-subscription:checked").val();

            if(typeof value == 'undefined'){
                if(checkoutData.getSubCheckboxValue()){
                    $('#checkout-with-subscription').prop('checked',checkoutData.getSubCheckboxValue());
                    $('#subscription-name').val(checkoutData.getSubFormData().subscription_name);
                    $('#start-date').val(checkoutData.getSubFormData().start_date);
                    $('#end-date').val(checkoutData.getSubFormData().end_date);

                    $('option[value=' + checkoutData.getSubFormData().frequency + ']')
                        .attr('selected',true);
                    $('#subscription-field').show();
                    return;
                }else {
                    $('#subscription-name').val('');
                    $('#start-date').val('');
                    $('#end-date').val('');
                    $('[name="days_checkbox"]').prop('checked', false);
                    $('#subscription-field').hide();
                    return ;
                }
            }
            if(typeof value == 'undefined'){
                $('#subscription-name').val('');
                $('#start-date').val('');
                $('#end-date').val('');
                $('[name="days_checkbox"]').prop('checked', false);
                $('#subscription-field').hide();
            }else {
                $('#subscription-field').show();
            }
        },
        showFormCheckedF: function () {
            var value = $("#checkout-with-subscription:checked").val();
            checkoutData.setSubCheckboxValue(typeof value != 'undefined');
            this.showSubscriptionForm();
        },
        daysCheckbox: function (){
            var $box = $(this);
            if ($box.is(":checked")) {
                var group = "input:checkbox[name='" + $box.attr("name") + "']";
                $(group).prop("checked", false);
                $box.prop("checked", true);
            } else {
                $box.prop("checked", false);
            }
        }
    });
});
