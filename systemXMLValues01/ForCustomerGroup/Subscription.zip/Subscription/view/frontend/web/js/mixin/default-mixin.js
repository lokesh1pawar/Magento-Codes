define(
    [
        'jquery',
        'jquery/ui',
        'underscore',
        'Magento_Ui/js/form/form',
        'ko',
        'Magento_Checkout/js/model/quote',
        'Magento_Checkout/js/model/resource-url-manager',
        'mage/storage',
        'Magento_Checkout/js/model/payment-service',
        'Magento_Checkout/js/model/payment/method-converter',
        'Magento_Checkout/js/model/error-processor',
        'Magento_Checkout/js/model/full-screen-loader',
        'Magento_Checkout/js/action/select-billing-address',
        'mage/utils/wrapper',
        'Magento_Checkout/js/checkout-data',
        'Magento_Checkout/js/model/shipping-save-processor/payload-extender'
    ],
    function ($, ui, _, Component, ko, quote, resourceUrlManager, storage, paymentService, methodConverter, errorProcessor, fullScreenLoader, selectBillingAddressAction, wrapper, checkoutData,payloadExtender) {
        'use strict';

        return function (defaultJS) {
            defaultJS.saveShippingInformation = wrapper.wrapSuper(defaultJS.saveShippingInformation, function (hash) {
                var payload;
                var selected = new Array();
                $('input[name=days_checkbox]:checked').each(function(){
                    selected.push(this.value);
                });
                if (!quote.billingAddress()) {
                    selectBillingAddressAction(quote.shippingAddress());
                }
                checkoutData.setSubFormData({
                    subscription_name:$('[name="subscription_name"]').val() ? $('[name="subscription_name"]').val() : null,
                    start_date:$('[name="start_date"]').val() ? $('[name="start_date"]').val() : null,
                    end_date: $('[name="end_date"]').val() ? $('[name="end_date"]').val() : null,
                    frequency: $('[name="frequency"] option:selected').val() ? $('[name="frequency"] option:selected').val() : null,
                    day: selected ? selected.join(',') : null
                })
                payload = {
                    addressInformation: {
                        shipping_address: quote.shippingAddress(),
                        billing_address: quote.billingAddress(),
                        shipping_method_code: quote.shippingMethod().method_code,
                        shipping_carrier_code: quote.shippingMethod().carrier_code,
                        extension_attributes: {
                            subscription_name : $('[name="subscription_name"]').val(),
                            start_date: $('[name="start_date"]').val(),
                            end_date: $('[name="end_date"]').val(),
                            frequency: $('[name="frequency"] option:selected').val(),
                            dob:$('#datepicker').val(),
                            days_checkbox: selected.join(',')
                        }
                    }
                };
                 payloadExtender(payload);

                fullScreenLoader.startLoader();

                return storage.post(
                    resourceUrlManager.getUrlForSetShippingInformation(quote),
                    JSON.stringify(payload)
                ).done(
                    function (response) {
                        quote.setTotals(response.totals);
                        paymentService.setPaymentMethods(methodConverter(response.payment_methods));
                        fullScreenLoader.stopLoader();
                    }
                ).fail(
                    function (response) {
                        errorProcessor.process(response);
                        fullScreenLoader.stopLoader();
                    }
                );
            });
            return defaultJS;
        }
    }
);
