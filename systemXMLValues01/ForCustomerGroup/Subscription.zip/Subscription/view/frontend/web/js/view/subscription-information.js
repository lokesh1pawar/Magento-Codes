define([
    'jquery',
    'ko',
    'uiComponent',
    'Magento_Checkout/js/model/step-navigator',
    'Magento_Checkout/js/model/sidebar',
    'Magento_Checkout/js/checkout-data'
], function ($, ko, Component, stepNavigator, sidebarModel, checkoutData) {
    'use strict';

    return Component.extend({
        defaults: {
            template: 'Echidna_Subscription/subscription-information'
        },
        initialize: function (config) {
            if (window.checkoutConfig.subscription){
                checkoutData.setSubFormData(window.checkoutConfig.subscription)
            }else {
                checkoutData.setSubFormData('');
            }
            return this._super(config);
        },
        backToShippingMethod: function () {
            sidebarModel.hide();
            stepNavigator.navigateTo('shipping', 'opc-shipping_method');
        },
        isVisibleSubscription: function (){
            return checkoutData.getSubFormData().subscription_name ? true : false;
        },
        getSubscriptionName: function () {
            return checkoutData.getSubFormData().subscription_name ? checkoutData.getSubFormData().subscription_name : null;
        },
        getStartDate: function (){
            return checkoutData.getSubFormData().start_date ? checkoutData.getSubFormData().start_date: null;
        },
        getEndDate: function (){
            return checkoutData.getSubFormData().end_date ? checkoutData.getSubFormData().end_date : null;
        },
        getFrequency: function (){
            return checkoutData.getSubFormData().frequency ? checkoutData.getSubFormData().frequency : null;
        },
        getDay: function (){
            return checkoutData.getSubFormData().day ? 'On Every ' + checkoutData.getSubFormData().day : null;
        }
    });
});
