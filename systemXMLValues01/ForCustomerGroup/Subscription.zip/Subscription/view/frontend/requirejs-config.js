var config = {
    config: {
        mixins: {
            "Magento_Checkout/js/model/shipping-save-processor/default": {
                "Echidna_Subscription/js/mixin/default-mixin": true
            }
        }
    }
};
