<?php

namespace Echidna\Subscription\Observer;

use Echidna\Subscription\Model\SubscriptionFactory;
use Magento\Checkout\Model\Session as CheckoutSession;
use Psr\Log\LoggerInterface;
use Magento\Framework\Stdlib\DateTime\DateTime;

/**
 * Class OrderSuccessAfter
 * @package Echidna\Subscription\Observer
 */
class OrderSuccessAfter implements \Magento\Framework\Event\ObserverInterface
{
    /**
     * @var SubscriptionFactory
     */
    protected $subscriptionFactory;
    protected $checkoutSession;
    /**
     * @var LoggerInterface
     */
    private $logger;
    protected $dateTime;

    /**
     * OrderSuccessAfter constructor.
     * @param SubscriptionFactory $subscriptionFactory
     * @param CheckoutSession $checkoutSession
     * @param LoggerInterface $logger
     */
    public function __construct(
        SubscriptionFactory $subscriptionFactory,
        CheckoutSession     $checkoutSession,
        LoggerInterface     $logger,
        DateTime            $dateTime
    )
    {
        $this->subscriptionFactory = $subscriptionFactory;
        $this->checkoutSession = $checkoutSession;
        $this->logger = $logger;
        $this->dateTime = $dateTime;
    }

    /**
     * @param \Magento\Framework\Event\Observer $observer
     */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        $order = $observer->getEvent()->getOrder();
        $orderId = $order->getId();
        try {
            if ($this->checkoutSession->getSubscriptionName() !== null && $this->checkoutSession->getStartDate()) {
                $order->setIsSubscription(1)->save();
                $frequency = explode(',', $this->checkoutSession->getDay());
                if ($frequency && $this->checkoutSession->getDay()) {
                    $subscriptionBeforeDate = $this->dateTime->date('m/d/Y', strtotime($this->checkoutSession->getStartDate()." -3 day"));
                    $currentDate = $this->dateTime->date('l');
                    foreach ($frequency as $value) {
                        if ($value == 'Sunday' || $value == 'Saturday'){
                            $value = 'Monday';
                        }
                        if ($currentDate == $value){
                            $day = $this->dateTime->date('m/d/Y', $this->checkoutSession->getStartDate());
                        }else{
                            $day = $this->dateTime->date('m/d/Y', $this->checkoutSession->getStartDate());
                        }
                        $subscription = $this->subscriptionFactory->create();
                        $subscription->setOrderId($orderId)
                            ->setSubscriptionName($this->checkoutSession->getSubscriptionName())
                            ->setFrequency($this->checkoutSession->getFrequency())
                            ->setStartDate($this->checkoutSession->getStartDate())
                            ->setEndDate($this->checkoutSession->getEndDate())
                            ->setWebsiteId($order->getStore()->getWebsiteId())
                            ->setDay($value)
                            ->setNextSubscriptionDate($day)->save();
                    }
                } else {
                    $subscription = $this->subscriptionFactory->create();
                    $subscription->setOrderId($orderId)
                        ->setSubscriptionName($this->checkoutSession->getSubscriptionName())
                        ->setFrequency($this->checkoutSession->getFrequency())
                        ->setStartDate($this->checkoutSession->getStartDate())
                        ->setEndDate($this->checkoutSession->getEndDate())
                        ->setWebsiteId($order->getStore()->getWebsiteId())
                        ->setDay($this->checkoutSession->getDay());
                    if ($this->checkoutSession->getFrequency() == \Echidna\Subscription\Model\Config\Source\Frequency::CRON_MONTHLY) {
                        $subscription->setNextSubscriptionDate($this->dateTime->date('m/d/Y', $subscription->getStartDate()));
                    } else if ($this->checkoutSession->getFrequency() == \Echidna\Subscription\Model\Config\Source\Frequency::CRON_YEARLY) {
                        $subscription->setNextSubscriptionDate($this->dateTime->date('m/d/Y', $subscription->getStartDate()));
                    }
                    $subscription->save();
                }
            }
        } catch (\Exception $exception) {
            $this->logger->critical($exception);
        }
    }
}
