<?php


namespace Echidna\Subscription\Helper;


use Magento\Framework\App\Area;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Exception\FileSystemException;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\MailException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Store\Model\ScopeInterface;
use PHPUnit\Exception;

class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
    const FREQUENCY = 'subscription/general/frequency';
    const DAYS = 'subscription/general/days';
    const IDENTITES = 'subscription/general/subscription_email_send_identity';
    const ADMIN_EMAIL = 'subscription/general/copy';
    const TEMPLATE_ID = 'subscription/general/subscription_template';
    const ECHIDNA_SUBSCRIPTION = "subscription/subscript_checkout/subscription_check";
    /**
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    protected $scopeConfig;

    protected $inlineTranslation;

    protected $_transportBuilder;

    protected $_storeManager;

    /**
     * @param \Magento\Framework\App\Helper\Context $context
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
     */
    public function __construct(
        \Magento\Framework\App\Helper\Context $context,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Framework\Mail\Template\TransportBuilder $transportBuilder,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\Translate\Inline\StateInterface $inlineTranslation
    )
    {
        $this->_scopeConfig = $scopeConfig;
        $this->inlineTranslation = $inlineTranslation;
        $this->_transportBuilder = $transportBuilder;
        $this->_storeManager = $storeManager;
        parent::__construct($context);
    }

    public function getFrequency()
    {
        $data = $this->scopeConfig->getValue(self::FREQUENCY, \Magento\Store\Model\ScopeInterface::SCOPE_WEBSITE);
        if ($data) {
            return explode(',', $data);
        } else {
            return '';
        }
    }

    public function getDays()
    {
        $data = $this->scopeConfig->getValue(self::DAYS, \Magento\Store\Model\ScopeInterface::SCOPE_WEBSITE);
        if ($data) {
            return explode(',', $data);
        } else {
            return '';
        }
    }

    public function getIdenties()
    {
        return $this->scopeConfig->getValue(self::IDENTITES, \Magento\Store\Model\ScopeInterface::SCOPE_WEBSITE);
    }

    /**
     * @param string $scope
     * @return array|false
     */
    public function getEmail($scope = \Magento\Store\Model\ScopeInterface::SCOPE_WEBSITE)
    {
        $data = $this->scopeConfig->getValue(
            self::ADMIN_EMAIL,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
        if (!empty($data)) {
            return array_map('trim', explode(',', $data));
        }
        return false;
    }

    public function getTemplateId()
    {
        return $this->scopeConfig->getValue(
            self::TEMPLATE_ID,
            \Magento\Store\Model\ScopeInterface::SCOPE_WEBSITE);
    }


    public function sendEmailSubscription(
        $order,
        $subscription
    )
    {
        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/subscription.log');
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);
        try {
        $from = $this->getIdenties();
        $this->inlineTranslation->suspend();
        $templateId = $this->getTemplateId();
        $transport = $this->_transportBuilder->setTemplateIdentifier($templateId)
            ->setTemplateOptions(
                [
                    'area' => Area::AREA_FRONTEND,
                    'store' => $order->getStoreId(),
                ]
            )
            ->setTemplateVars(['order' => $order, 'subscription' => $subscription])
            ->setFrom($from);
        $transport->addTo($order->getCustomerEmail());
        $transport->getTransport()->sendMessage();
        $this->inlineTranslation->resume();
            $logger->info("Subscription Email successfully triggered");
        }catch (Exception $exception){
            $logger->info($exception);
        }
        return $this;
    }

    public function getGeneralConfig()
    {
        return $this->_scopeConfig->getValue("subscription/subscript_checkout/subscription_check",
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE,
            $this->_storeManager->getStore()->getStoreId()
        );
    }
}