<?php


namespace Echidna\Subscription\Cron;


use Echidna\Subscription\Helper\Data;
use Echidna\Subscription\Model\SubscriptionFactory;
use Magento\Framework\Stdlib\DateTime\DateTime;
use Magento\Sales\Model\OrderFactory;
use Magento\Store\Model\StoreManagerInterface;
use Psr\Log\LoggerInterface;

class SubscriptionCron
{
    const FROM_TIME = ' 00:00:00';
    const TO_TIME = ' 23:59:59';
    protected $orderFactory;
    protected $subscriptionFactory;
    protected $storeManager;
    protected $dateTime;
    protected $helperData;
    protected $logger;

    public function __construct(
        OrderFactory          $orderFactory,
        SubscriptionFactory   $subscriptionFactory,
        Data                  $helperData,
        StoreManagerInterface $storeManager,
        DateTime              $dateTime,
        LoggerInterface       $logger
    )
    {
        $this->orderFactory = $orderFactory;
        $this->subscriptionFactory = $subscriptionFactory;
        $this->helperData = $helperData;
        $this->storeManager = $storeManager;
        $this->dateTime = $dateTime;
        $this->logger = $logger;
    }

    public function execute()
    {
        try {
            $currentDate = $this->dateTime->date('m/d/Y');
            $nextSubscriptionDate = $this->dateTime->date('m/d/Y', strtotime($currentDate . "3 day"));
            $orderCollection = $this->orderFactory->create()
                ->getCollection()
                ->addFieldToSelect('*')
                ->addFieldToFilter('is_subscription', 1);
            if ($orderCollection) {
                foreach ($orderCollection as $order) {
                    $subscriptionData = $this->subscriptionFactory->create()->getCollection()->addFieldToSelect('*')->addFieldToFilter('order_id', $order->getId())->addFieldToFilter('next_subscription_date', $nextSubscriptionDate);
                    if ($subscriptionData->getData()) {
                        foreach ($subscriptionData as $subscription) {
                            if ($subscription->getFrequency() == \Echidna\Subscription\Model\Config\Source\Frequency::CRON_WEEKLY) {
                                if ($this->dateTime->date('m/d/Y', $subscription->getStartDate()) <= $currentDate) {
                                    if ($subscription->getStartDate() >= $subscription->getEndDate() ?? $subscription->getNextSubscriptionDate()) {
                                        $this->helperData->sendEmailSubscription($order, $subscription);
//                                        $subscription->setNextSubscriptionDate($this->dateTime->date('m/d/Y', strtotime($this->dateTime->date('Y-m-d', $subscription->getNextSubscriptionDate()) .' next '. $subscription->getDay())))->save();
                                    }
                                }
                            } else if ($subscription->getFrequency() == \Echidna\Subscription\Model\Config\Source\Frequency::CRON_MONTHLY) {
                                if ($currentDate >= $this->dateTime->date('m/d/Y', $subscription->getStartDate())) {
                                    if ($subscription->getStartDate() >= $subscription->getEndDate() ?? $subscription->getNextSubscriptionDate()) {
                                        $this->helperData->sendEmailSubscription($order, $subscription);
//                                        $subscription->setNextSubscriptionDate($this->dateTime->date('m/d/Y', strtotime($subscription->getNextSubscriptionDate() . '+1 month')))->save();
                                    }
                                }
                            } else if ($subscription->getFrequency() == \Echidna\Subscription\Model\Config\Source\Frequency::CRON_YEARLY) {
                                if ($currentDate >= $this->dateTime->date('m/d/Y', $subscription->getStartDate())) {
                                    if ($subscription->getStartDate() >= $subscription->getEndDate() ?? $subscription->getNextSubscriptionDate()) {
                                        $this->helperData->sendEmailSubscription($order, $subscription);
//                                        $subscription->setNextSubscriptionDate($this->dateTime->date('m/d/Y', strtotime($subscription->getNextSubscriptionDate() . '+1 years')))->save();
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } catch (\Exception $exception) {
            $this->logger->critical($exception);
        }
    }
}
