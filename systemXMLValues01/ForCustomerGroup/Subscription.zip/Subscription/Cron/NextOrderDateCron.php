<?php
/**
 * NextOrderDateCron
 *
 * @copyright Copyright © 2021 Staempfli AG. All rights reserved.
 * @author    juan.alonso@staempfli.com
 */

namespace Echidna\Subscription\Cron;

use Echidna\Subscription\Helper\Data;
use Echidna\Subscription\Model\SubscriptionFactory;
use Magento\Framework\Stdlib\DateTime\DateTime;
use Magento\Sales\Model\OrderFactory;
use Magento\Store\Model\StoreManagerInterface;
use Psr\Log\LoggerInterface;

class NextOrderDateCron
{
    const FROM_TIME = ' 00:00:00';
    const TO_TIME = ' 23:59:59';
    const ENABLED = 1;
    protected $orderFactory;
    protected $subscriptionFactory;
    protected $storeManager;
    protected $dateTime;
    protected $helperData;
    protected $logger;

    public function __construct(
        OrderFactory          $orderFactory,
        SubscriptionFactory   $subscriptionFactory,
        Data                  $helperData,
        StoreManagerInterface $storeManager,
        DateTime              $dateTime,
        LoggerInterface       $logger
    )
    {
        $this->orderFactory = $orderFactory;
        $this->subscriptionFactory = $subscriptionFactory;
        $this->helperData = $helperData;
        $this->storeManager = $storeManager;
        $this->dateTime = $dateTime;
        $this->logger = $logger;
    }

    public function execute()
    {
        try {
            $currentDate = $this->dateTime->date('m/d/Y');
            $subscriptionData = $this->subscriptionFactory->create()->getCollection()->addFieldToSelect('*')->addFieldToFilter('next_subscription_date', $currentDate)->addFieldToFilter('status', self::ENABLED);
            if ($subscriptionData->getData()) {
                foreach ($subscriptionData as $subscription) {
                    if ($subscription->getFrequency() == \Echidna\Subscription\Model\Config\Source\Frequency::CRON_WEEKLY) {
                        if ($subscription->getStartDate() >= $subscription->getEndDate() ?? $subscription->getNextSubscriptionDate()) {
                            if ($this->dateTime->date('m/d/Y', $subscription->getNextSubscriptionDate()) <= $currentDate) {
                                $subscription->setNextSubscriptionDate($this->dateTime->date('m/d/Y', strtotime($this->dateTime->date('Y-m-d', $subscription->getNextSubscriptionDate()) . ' next ' . $subscription->getDay())))->save();
                            }
                        }
                    } else if ($subscription->getFrequency() == \Echidna\Subscription\Model\Config\Source\Frequency::CRON_MONTHLY) {
                        if ($subscription->getStartDate() >= $subscription->getEndDate() ?? $subscription->getNextSubscriptionDate()) {
                            if ($currentDate >= $this->dateTime->date('m/d/Y', $subscription->getNextSubscriptionDate())) {
                                $subscription->setNextSubscriptionDate($this->dateTime->date('m/d/Y', strtotime($subscription->getNextSubscriptionDate() . '+1 month')))->save();
                            }
                        }
                    } else if ($subscription->getFrequency() == \Echidna\Subscription\Model\Config\Source\Frequency::CRON_YEARLY) {
                        if ($subscription->getStartDate() >= $subscription->getEndDate() ?? $subscription->getNextSubscriptionDate()) {
                            if ($currentDate >= $this->dateTime->date('m/d/Y', $subscription->getNextSubscriptionDate())) {
                                $subscription->setNextSubscriptionDate($this->dateTime->date('m/d/Y', strtotime($subscription->getNextSubscriptionDate() . '+1 years')))->save();
                            }
                        }
                    }
                }
            }
        } catch (\Exception $exception) {
            $this->logger->critical($exception);
        }
    }
}
