<?php

namespace Plumtree\YotpoLoyalty\Helper;
use Magento\Framework\App\Config\ScopeConfigInterface;

class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
    /**
     * Admin configuration paths
     *
     */
    const IS_ENABLED            = 'section_id/general/enable';

    const CUSTOMER_GROUP_VALUES   	= 'section_id/general/customer_group_list';	
    /**
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    protected $scopeConfig;
    protected $_customerSession;
    protected $_storeManager;


 
    /**
     * Data constructor
     * @param \Magento\Framework\App\Helper\Context $context
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
     */
    public function __construct(
        \Magento\Framework\App\Helper\Context $context,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Customer\Model\Session $customerSession
        // \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig


    ) {
        parent::__construct($context);
        $this->_customerSession = $customerSession;
        $this->_scopeConfig = $scopeConfig;
        $this->_storeManager = $storeManager;

            
    }

    /**
     * @return $isEnabled
     */
    // public function isEnabled()
    // {
    //     $isEnabled = $this->scopeConfig->getValue(self::IS_ENABLED, 
    //         \Magento\Store\Model\ScopeInterface::SCOPE_STORE
    //     );
 
    //     return $isEnabled;
    // }

    /**
     * @return $displayText
     */
    public function getCustomerConfig()
        {

    // echo "******" ;
    // exit();
       if($this->_customerSession->isLoggedIn()){
       
       // if($this->_customerSession->isLoggedIn()){
           //     $customerGroup=$this->_customerSession->getCustomer()->getGroupId();
           // }

       $customerGroup=$this->_customerSession->getCustomer()->getGroupId();
           
       $groupList = $this->_scopeConfig->getValue("section_id/general/customer_group_list",
           \Magento\Store\Model\ScopeInterface::SCOPE_STORE,
           $this->_storeManager->getStore()->getStoreId()
       );

      $groupArray = explode(",", $groupList);

       $writer = new \Zend_Log_Writer_Stream(BP . '/var/log/lokesh.log');
               $logger = new \Zend_Log();
               $logger->addWriter($writer);
               $logger->info("Store ID");
               $logger->info($this->_storeManager->getStore()->getStoreId());
               $logger->info("Customer Group ID");
               $logger->info($customerGroup);
               $logger->info($groupList);

           if(in_array($customerGroup, $groupArray)){
             return true;
           }
          
       }
             return false;
   }
}
