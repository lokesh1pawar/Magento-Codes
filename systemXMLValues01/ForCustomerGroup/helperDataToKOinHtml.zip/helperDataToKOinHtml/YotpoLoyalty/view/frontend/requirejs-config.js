var config = 
{
    map: 
    {
        '*': 
        {
            'Yotpo_Loyalty/js/view/summary/custom':'Plumtree_YotpoLoyalty/js/view/summary/custom'
        }
    }
};