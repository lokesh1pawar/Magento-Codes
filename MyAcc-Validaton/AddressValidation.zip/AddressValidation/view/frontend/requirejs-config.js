/**
 * PTG Implemented.
 *
 */
 var config = {
    map: {
        '*': {
            'Magento_Checkout/js/view/shipping': 'Plumtree_AddressValidation/js/view/shipping'
        }
    }
};
