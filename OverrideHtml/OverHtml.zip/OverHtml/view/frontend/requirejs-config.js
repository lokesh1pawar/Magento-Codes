var config = {
    map: {
        '*': {
            'Magento_Checkout/template/minicart/content.html': 'Lokesh_OverHtml/template/minicart/content.html'
        },
    }
};