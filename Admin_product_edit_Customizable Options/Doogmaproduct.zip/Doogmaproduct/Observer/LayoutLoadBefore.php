<?php
namespace Plumtree\Doogmaproduct\Observer;

class LayoutLoadBefore implements \Magento\Framework\Event\ObserverInterface
{
    /**
     * @var \Magento\Framework\Registry
     */
    private $registry;

    public function __construct(
       \Magento\Framework\Registry $registry
    ) {
        $this->registry = $registry;
    }


    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        $product = $this->registry->registry('current_product');


        if (!$product) {
          return $this;
        }

        if ($product->getCustomlayout()) {
           $layout = $observer->getLayout();
           //$layout->getUpdate()->addHandle('customlayout');
		       $layout->getUpdate()->addHandle('catalog_product_view_customlayout_1');
        }
        return $this;
    }
}
