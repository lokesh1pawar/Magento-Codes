<?php
use Magento\Framework\Component\ComponentRegistrar;
ComponentRegistrar::register(ComponentRegistrar::MODULE,'Plumtree_Doogmaproduct',__DIR__);
