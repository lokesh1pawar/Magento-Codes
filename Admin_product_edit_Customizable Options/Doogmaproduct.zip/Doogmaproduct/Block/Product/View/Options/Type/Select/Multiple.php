<?php

declare(strict_types=1);

namespace Plumtree\Doogmaproduct\Block\Product\View\Options\Type\Select;


use Magento\Catalog\Block\Product\View\Options\AbstractOptions;
use Magento\Catalog\Model\Product\Option;
use Magento\Framework\View\Element\Html\Select;

class Multiple extends \Magento\Catalog\Block\Product\View\Options\AbstractOptions
{
    protected function _toHtml()
    {
        $option = $this->getOption();
        $optionType = $option->getType();
        $configValue = $this->getProduct()->getPreconfiguredValues()->getData('options/' . $option->getId());
        $require = $option->getIsRequire() ? ' required' : '';
        $extraParams = '';
        /** @var Select $select */
		$defaultTitle = preg_replace("/\s+/", "", strtolower($option->getDefaultTitle()));
		if (strpos($defaultTitle, 'secondary') !== false) {
			$defaultTitle = 'wordmark-2';
		}
		
		if(strtolower($option->getDefaultTitle())=='size'){
			$select = $this->getLayout()->createBlock(
				Select::class
			)->setData(
				[
					'id' => 'select_' . $option->getId(),
					'class' => $require . ' product-custom-option admin__control-select doogma-'.$defaultTitle.''
				]
			);			
		}else{
			$select = $this->getLayout()->createBlock(
				Select::class
			)->setData(
				[
					'id' => 'select_' . $option->getId(),
					'class' => $require . ' product-custom-option admin__control-select doogma-'.$defaultTitle.'color'
				]
			);	
		}
        $select = $this->insertSelectOption($select, $option);
        $select = $this->processSelectOption($select, $option);
        if ($optionType === Option::OPTION_TYPE_MULTIPLE) {
            $extraParams = ' multiple="multiple"';
        }
        if (!$this->getSkipJsReloadPrice()) {
            $extraParams .= ' onchange="opConfig.reloadPrice()"';
        }
        $extraParams .= ' data-selector="' . $select->getName() . '"';
        $select->setExtraParams($extraParams);
        if ($configValue) {
            $select->setValue($configValue);
        }
        return $select->getHtml();
    }

    /**
     * Returns select with inserted option give as a parameter
     *
     * @param Select $select
     * @param Option $option
     * @return Select
     */
    private function insertSelectOption(Select $select, Option $option): Select
    {
        $require = $option->getIsRequire() ? ' required' : '';
        if ($option->getType() === Option::OPTION_TYPE_DROP_DOWN) {
            $select->setName('options[' . $option->getId() . ']')->addOption('', __('-- Please Select --'));
        } else {
            $select->setName('options[' . $option->getId() . '][]');
            $select->setClass('multiselect admin__control-multiselect' . $require . ' product-custom-option');
        }

        return $select;
    }

    /**
     * Returns select with formated option prices
     *
     * @param Select $select
     * @param Option $option
     * @return Select
     */
    private function processSelectOption(Select $select, Option $option): Select
    {
        $store = $this->getProduct()->getStore();
        foreach ($option->getValues() as $_value) {
            $isPercentPriceType = $_value->getPriceType() === 'percent';
            $priceStr = $this->_formatPrice(
                [
                    'is_percent' => $isPercentPriceType,
                    'pricing_value' => $_value->getPrice($isPercentPriceType)
                ],
                false
            );

			$_description = '';
			
			
			if($_value->getDescription()){
				$_description = $_value->getDescription();
				$_description = (str_replace(' ', '-', strtolower($_description)));
				$_description = (str_replace('#', '', strtolower($_description)));	
			}
			 
			// code for custom swatch image , string concated with || , first parth doogma value , second will be path to image
			if(preg_match("/\|\|/",$_value->getDescription()))
			{
				$_datavalue = explode("||",$_value->getDescription());
				if(isset($_datavalue[1]) && $_datavalue[1] !="" )
				{	$_colorValue = explode("#",$_datavalue[0]);
					$_description = $_colorValue[1];
				if(isset($_colorValue[2]))
						$_description = $_colorValue[1]."#".$_colorValue[2];
				}
			}
			else if(preg_match("/\#/",$_value->getDescription()))
			{
				$_colorValue = explode("#",$_value->getDescription());
				$_description = $_colorValue[1];
				if(isset($_colorValue[2]))
						$_description = $_colorValue[1]."#".$_colorValue[2];
			}
			 
            $select->addOption(
                $_value->getOptionTypeId(),
                $_value->getTitle() . ' ' . strip_tags($priceStr) . '',
                [
                    'price' => $this->pricingHelper->currencyByStore(
                        $_value->getPrice(true),
                        $store,
                        false
                    ),
					'data-doogma-value' => $_description
                    
                ]
            );
        }

        return $select;
    }

}
