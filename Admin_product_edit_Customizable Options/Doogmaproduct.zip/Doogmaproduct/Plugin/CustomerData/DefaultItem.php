<?php

namespace Plumtree\Doogmaproduct\Plugin\CustomerData;

use Magento\Quote\Model\Quote\Item;

class DefaultItem
{
    public function aroundGetItemData(\Magento\Checkout\CustomerData\DefaultItem $subject, \Closure $proceed, Item $item)
    {
        $data = $proceed($item);
        $_options = $item->getProduct()->getTypeInstance(true)->getOrderOptions($item->getProduct());
    		if(isset($_options['options'])){
            $customOptions = $_options['options'];
            $designLink = '';
            $doogmaImage = '';
            if (!empty($customOptions)) {
              foreach ($customOptions as $_option){
                if($_option['label'] == 'saveddesignlink'){
                  $designLink = $_option['value'];
                }
                if($_option['label'] == 'savedimagelink'){
                  $doogmaImage = $_option['value'];
                }
              }
            }
            $itemUrl = ($designLink != '') ? $designLink : $item->getProduct()->getProductUrl();

            $atts = ["custom_link" => $itemUrl,"doogma_image" => $doogmaImage];

            return array_merge($data, $atts);
    		}else{
            $itemUrl = $item->getProduct()->getProductUrl();
            $atts = ["custom_link" => $itemUrl, "doogma_image" => ''];
            return array_merge($data, $atts);
        }
    }
}
