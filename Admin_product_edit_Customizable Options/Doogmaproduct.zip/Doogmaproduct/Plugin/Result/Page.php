<?php
namespace Plumtree\Doogmaproduct\Plugin\Result;

use Magento\Framework\App\ResponseInterface;

class Page
{
	protected $_registry;
	private $context;
	
	public function __construct(
		\Magento\Framework\Registry $registry,
		\Magento\Framework\View\Element\Context $context
	) {
		$this->_registry = $registry;
		$this->context = $context;
	}

	public function beforeRenderResult(
	\Magento\Framework\View\Result\Page $subject,
	ResponseInterface $response
	){
	if($this->context->getRequest()->getFullActionName() == 'catalog_product_view'){
		$_current_product = $this->_registry->registry('current_product');
		if($_current_product->getCustomlayout()==1){
			$subject->getConfig()->addBodyClass('doogma-product');
		}
	}

	return [$response];
	}
}