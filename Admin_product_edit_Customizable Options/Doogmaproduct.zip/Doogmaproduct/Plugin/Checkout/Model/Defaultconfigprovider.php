<?php
namespace Plumtree\Doogmaproduct\Plugin\Checkout\Model;

use Magento\Checkout\Model\Session as CheckoutSession;

class Defaultconfigprovider
{
    protected $checkoutSession;

    public function __construct(
      CheckoutSession $checkoutSession
    ){
      $this->checkoutSession = $checkoutSession;
    }

    public function afterGetConfig(
      \Magento\Checkout\Model\DefaultConfigProvider $subject, array $result
    ){
        $items = $result['totalsData']['items'];
        foreach ($items as $index => $item) {
          $quoteItem = $this->checkoutSession->getQuote()->getItemById($item['item_id']);
          $itemId = $quoteItem->getId();
          $doogmaImage = '';
          $_options = $quoteItem->getProduct()->getTypeInstance(true)->getOrderOptions($quoteItem->getProduct());
          if(isset($_options['options'])){
            $customOptions = $_options['options'];
            if (!empty($customOptions)) {
              foreach ($customOptions as $_option){
                if($_option['label'] == 'savedimagelink'){
                  $doogmaImage = $_option['value'];
                }
              }
            }
          }
          $result['imageData'][$itemId]['doogma_image'] = $doogmaImage;
        }
        return $result;
    }
}
