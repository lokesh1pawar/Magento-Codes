<?php declare(strict_types=1);
namespace Echidna\Blog\Model\ResourceModel;

use Echidna\Blog\Model;
use Magento\Framework\Model\ResourceModel\Db\AbstractDb;

class Post extends AbstractDb
{
	const MAIN_TABLE = 'ehidna_blog_post';
    const ID_FIELD_NAME = 'id';
    
	protected function _construct()
    {
    	$this->_init(self::MAIN_TABLE, self::ID_FIELD_NAME);

    }
}