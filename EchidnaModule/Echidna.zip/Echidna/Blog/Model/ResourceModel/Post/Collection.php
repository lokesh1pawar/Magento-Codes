<?php declare(strict_types=1);
namespace Echidna\Blog\Model\ResourceModel\Post;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

class Collection extends AbstractCollection
{
	 $this->_init(\Echidna\Blog\Model\ResourceModel\Post::class, \Echidna\Blog\Model\ResourceModel\Post::class);
}