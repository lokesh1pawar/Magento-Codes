<?php
namespace Echidna\Blog\Controller\Post;

use Magento\Framework\View\Result\PageFactory;

class ListAction extends \Magento\Framework\App\Action\Action
{
	protected $pageFactory;

    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        PageFactory $pageFactory
    )
    {
        $this->pageFactory = $pageFactory;
        parent::__construct($context);
    }

    public function execute()
    {
    	//die("hello");
        $page = $this->pageFactory->create();
        return $page;
    }
}