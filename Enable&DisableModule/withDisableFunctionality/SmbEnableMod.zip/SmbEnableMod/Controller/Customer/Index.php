<?php 
namespace Lokesh\SmbEnableMod\Controller\Customer;  

use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\App\Action\HttpGetActionInterface as HttpGetActionInterface;

class Index extends  \Lokesh\SmbEnableMod\Controller\Index implements HttpGetActionInterface {

public function execute() { 
    return $this->resultFactory->create(ResultFactory::TYPE_PAGE);

  } 
} 
?>