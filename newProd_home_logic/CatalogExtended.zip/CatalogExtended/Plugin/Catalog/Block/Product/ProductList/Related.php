<?php

namespace Plumtree\CatalogExtended\Plugin\Catalog\Block\Product\ProductList;

class Related
{
    /**
     * Get collection items
     *
     * @return Collection
     */
    public function afterGetItems(\Magento\Catalog\Block\Product\ProductList\Related $subject, $itemCollection)
    {
        $itemCollection->getSelect()->reset('order');
        $itemCollection->setOrder('position', 'ASC');
        return $itemCollection;
    }
}
