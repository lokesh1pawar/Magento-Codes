<?php
namespace Plumtree\CatalogExtended\Block\Index;

use Magento\Framework\View\Element\Template;

class View extends Template
{
	protected $_cart;
	protected $_checkoutSession;
	protected $_productRepository;

	public function __construct(
		\Magento\Checkout\Model\Cart $cart,
    \Magento\Checkout\Model\Session $checkoutSession,
		\Magento\Catalog\Api\ProductRepositoryInterface $productRepository,
		Template\Context $context,
		array $data = []
	)
	{
		$this->_cart = $cart;
    $this->_checkoutSession = $checkoutSession;
		$this->_productRepository = $productRepository;
		parent::__construct($context, $data);
	}

	protected function _prepareLayout()
  {
		return parent::_prepareLayout();
	}

	public function getLoadProduct($productId)
  {
		return $this->_productRepository->getById($productId);
	}

	public function getCart()
  {
		return $this->_cart;
	}
  public function getQuote()
  {
    return $this->_checkoutSession->getQuote();
  }
}
