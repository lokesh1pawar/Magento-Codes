<?php

namespace Plumtree\CatalogExtended\Block\Home;

use Magento\Catalog\Model\Product\Attribute\Source\Status;
use Magento\Framework\App\ActionInterface;

class Product extends \Magento\Catalog\Block\Product\AbstractProduct
{
    protected $_categoryCollectionFactory;
    protected $_catalogProductVisibility;
    protected $_orderItemCollectionFactory;
    protected $_productRepository;
    protected $_resource;
    protected $_storeManager;
    protected $_localeDate;
    protected $_registry;
    protected $urlHelper;

    public function __construct(
        \Magento\Catalog\Block\Product\Context $context,
        \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $productCollectionFactory,
        \Magento\Catalog\Model\Product\Visibility $catalogProductVisibility,
        \Magento\Framework\App\ResourceConnection $resource,
        \Magento\Sales\Model\ResourceModel\Order\Item\CollectionFactory $orderItemCollectionFactory,
        \Magento\Catalog\Api\ProductRepositoryInterface $productRepository,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\Stdlib\DateTime\DateTime $date,
        \Magento\Framework\Url\Helper\Data $urlHelper,
        \Magento\Framework\Registry $registry,
        array $data = []
    )
    {
        $this->_productCollectionFactory = $productCollectionFactory;
        $this->_catalogProductVisibility = $catalogProductVisibility;
        $this->_productRepository = $productRepository;
        $this->_orderItemCollectionFactory = $orderItemCollectionFactory;
        $this->urlHelper = $urlHelper;
        $this->_resource = $resource;
        $this->_storeManager = $storeManager;
        $this->_registry = $registry;
        $this->_localeDate = $date;
        parent::__construct($context, $data);
    }

    public function getNewProductCollection()
    {
        $todayStartOfDayDate = $this->_localeDate->date()->setTime(0, 0, 0)->format('Y-m-d H:i:s');

        $todayEndOfDayDate = $this->_localeDate->date()->setTime(23, 59, 59)->format('Y-m-d H:i:s');
        
        /** @var $collection \Magento\Catalog\Model\ResourceModel\Product\Collection */
        $collection = $this->_productCollectionFactory->create();
        $collection->setVisibility($this->_catalogProductVisibility->getVisibleInCatalogIds());
 

        $collection = $collection->addAttributeToSelect('*')
        ->addStoreFilter()->addAttributeToFilter(
            'news_from_date',
            [
                'or' => [
                    0 => ['date' => true, 'to' => $todayEndOfDayDate],
                    1 => ['is' => new \Zend_Db_Expr('null')],
                ]
            ],
            'left'
        )->addAttributeToFilter(
            'news_to_date',
            [
                'or' => [
                    0 => ['date' => true, 'from' => $todayStartOfDayDate],
                    1 => ['is' => new \Zend_Db_Expr('null')],
                ]
            ],
            'left'
        )->addAttributeToFilter(
            [
                ['attribute' => 'news_from_date', 'is' => new \Zend_Db_Expr('not null')],
                ['attribute' => 'news_to_date', 'is' => new \Zend_Db_Expr('not null')],
            ]
        )->addAttributeToSort(
            'news_from_date',
            'desc'
        );
        // $collection->setOrder('news_from_date', 'DESC');
        // $collection->getSelect()->order('news_from_date DESC');
        $collection->getSelect()->limit(5);

       
        // foreach ($collection as $product) {
        //     echo "Product ID: " . $product->getId() . "<br>";
        //     echo "Product Name: " . $product->getName() . "<br>";
        // }
        // exit;
        return $collection;
    }

    public function getSpecialProductCollection()
    {
        $collection = $this->_productCollectionFactory->create();
        $collection->addAttributeToSelect('*');
        $collection->addAttributeToFilter('is_special',['eq' => 1]);
        $collection->setVisibility($this->_catalogProductVisibility->getVisibleInCatalogIds());
        $collection->addAttributeToFilter('status', Status::STATUS_ENABLED);
        $collection->getSelect()->order('entity_id ASC')->limit(5);
        return $collection;
    }

    public function getBestSellerProducts()
    {
        $store = $this->_storeManager->getStore();
        $storeId = $store->getId();
        $orderTable = $this->_resource->getTableName('sales_order');

        $orderItemCollection = $this->_orderItemCollectionFactory->create();
        $orderItemCollection
                    ->addFieldToSelect('order_id')
                    ->addFieldToSelect('product_id')
                    ->addFieldToFilter('main_table.store_id', ['eq' => $storeId])
                    ->addFieldToFilter('main_table.parent_item_id', ['null' => true]);
                    //->addFieldToFilter('main_table.product_type', ['in' => ['configurable','bundle']]);

        $orderItemCollection->getSelect()
                    ->join(array('order' => $orderTable), 'main_table.order_id = order.entity_id',  array('order.status','order.customer_id'))
                    ->where("order.status <> 'canceled'")
                    ->columns('SUM(main_table.qty_ordered) AS total_qty')
                    ->order(array('total_qty desc'))
                    ->group(array('main_table.product_id'));

        $orderItemCollection->getSelect()->limit(20);
        //->orderRand();
        return $orderItemCollection;
    }

    public function getAddToCartPostParams(\Magento\Catalog\Model\Product $product)
    {
        $url = $this->getAddToCartUrl($product);
        return [
            'action' => $url,
            'data' => [
                'product' => (int) $product->getEntityId(),
                ActionInterface::PARAM_NAME_URL_ENCODED => $this->urlHelper->getEncodedUrl($url),
            ]
        ];
    }

    public function getProductById($id)
    {
        return $this->_productRepository->getById($id);
    }

    public function getProductBySku($sku)
    {
        return $this->_productRepository->get($sku);
    }
}
