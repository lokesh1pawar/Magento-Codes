var config = {
    map: {
        '*': {
            ptowlCarousel: 'Plumtree_CatalogExtended/js/owl.carousel'
        }
    }
};
