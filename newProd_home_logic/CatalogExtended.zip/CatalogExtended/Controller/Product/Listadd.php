<?php

namespace Plumtree\CatalogExtended\Controller\Product;

use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\App\Action\Context;

class Listadd extends \Magento\Framework\App\Action\Action
{
    protected $formKey;
    protected $cart;
    protected $product;
	protected $_resultPageFactory;

    public function __construct(
      \Magento\Framework\App\Action\Context $context,
      \Magento\Framework\Data\Form\FormKey $formKey,
      \Magento\Checkout\Model\Cart $cart,
      \Magento\Catalog\Model\Product $product,
	  \Magento\Framework\View\Result\PageFactory $resultPageFactory,
      array $data = []
    ){
		$this->_resultPageFactory = $resultPageFactory;
        $this->formKey = $formKey;
        $this->cart = $cart;
        $this->product = $product;
        parent::__construct($context);
    }

    public function execute()
    {
		$resultPage = $this->_resultPageFactory->create();
		
        $selectedItems = $this->getRequest()->getPost('selectedItems');
        $selectedItems = explode(",",$selectedItems);
		
		$result = array();		
		$productCount = count($selectedItems);

        try{
			foreach($selectedItems as $key => $idqt){
				$qids = explode("_",$idqt);
				$product_id = $qids[0];
				$qty = $qids[1];
				$this->cart->addProduct($product_id, array('qty' => $qty));
			}
			$this->cart->save();
			$this->messageManager->addSuccess(__('You have added selected products to cart successfully.'));
			$status = 1;
			
			if($productCount == 1){
				$data['addedproductid'] = $product_id;
				$data['addedproductqty'] = $qty;
				$block = $resultPage->getLayout()
						->createBlock('Plumtree\CatalogExtended\Block\Index\View')
						->setTemplate('Plumtree_CatalogExtended::view.phtml')
						->setData('data',$data)
						->toHtml();
						
				$result['output'] = $block;
			}
			
        }
        catch (\Magento\Framework\Exception\LocalizedException $e) {
            $this->messageManager->addException(
            $e,
            __('%1', $e->getMessage())
            );
            $status = 0;
        } catch (\Exception $e) {
            $this->messageManager->addException($e, __('error.'));
            $status = 0;
        }
        
        $result['status'] = $status;
		$result['productcount'] = $productCount;
        $resultJson = $this->resultFactory->create(ResultFactory::TYPE_JSON);
        $resultJson->setData($result);
        return $resultJson;
    }
}
