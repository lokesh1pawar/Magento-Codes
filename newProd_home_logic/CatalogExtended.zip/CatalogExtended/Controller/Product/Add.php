<?php


namespace Plumtree\CatalogExtended\Controller\Product;

use Magento\Framework\Controller\ResultFactory;

class Add extends \Magento\Framework\App\Action\Action
{
	/**
     * @var \Magento\Framework\View\Result\PageFactory
     */
    protected $resultPageFactory;
	protected $jsonHelper;

    /**
     * @var \Magento\Checkout\Model\Session
     */
    protected $checkoutSession;

    /**
     * @var \Magento\Quote\Api\CartRepositoryInterface
     */
    protected $cartRepository;

    /**
     * @var \Magento\Catalog\Model\ProductFactory
     */
    protected $productFactory;
    protected $cart;

    /**
     * Constructor
     *
     * @param \Magento\Framework\App\Action\Context  $context
     * @param \Magento\Framework\Json\Helper\Data $jsonHelper
     */
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        \Magento\Framework\Json\Helper\Data $jsonHelper,
		    \Magento\Checkout\Model\Session $checkoutSession,
        \Magento\Quote\Api\CartRepositoryInterface $cartRepository,
        \Magento\Catalog\Model\ProductFactory $productFactory,
        \Magento\Checkout\Model\Cart $cart,
        \Psr\Log\LoggerInterface $logger
    ) {
        $this->resultPageFactory = $resultPageFactory;
        $this->jsonHelper = $jsonHelper;
		    $this->checkoutSession = $checkoutSession;
        $this->cartRepository = $cartRepository;
        $this->productFactory = $productFactory;
        $this->cart = $cart;
        $this->logger = $logger;
        parent::__construct($context);
    }

    /**
     * Execute view action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
    		$resultPage = $this->resultPageFactory->create();

    		try {
      			$result = array();
      			$postedData = $this->getRequest()->getParams();
            $quote = $this->checkoutSession->getQuote();

            $qty = $postedData['qty'];//product quantity
      			$mainProductId = $postedData['product'];
      			$mainProductQty = $postedData['qty'];
      			$product = $this->productFactory->create()->load($mainProductId);
      			//$quote->addProduct($product,intval($mainProductQty));
            $params = array();
            $params = [
                'product' => $mainProductId,
                'qty' => $qty
            ];
            $this->cart->addProduct($product, $params);
            $this->cart->save();

            $addedRelated = 0;
            if(isset($postedData['relatedproducts'])){
              foreach($postedData['relatedproducts'] as $productId => $qty){
                if( $qty > 0 ){
                  $params = array();
                  $product = $this->productFactory->create()->load($productId);
                  if($product->getId()){
  			            $addedRelated++;
                    // $quote->addProduct(
                    //     $product,
                    //     intval($qty)
                    // );
                    $params = [
                        'product' => $productId,
                        'qty' => $qty
                    ];
                    $this->cart->addProduct($product, $params);
                    $this->cart->save();
                  }
                }
              }
            }

            // $this->cartRepository->save($quote);
            // $this->checkoutSession->replaceQuote($quote)->unsLastRealOrderId();
            $this->messageManager->addSuccess(__('You have added products to cart successfully.'));

      			if($addedRelated == 0){
      				$data['addedproductid'] = $mainProductId;
      				$data['addedproductqty'] = $mainProductQty;
      				$block = $resultPage->getLayout()
      						->createBlock('Plumtree\CatalogExtended\Block\Index\View')
      						->setTemplate('Plumtree_CatalogExtended::view.phtml')
      						->setData('data',$data)
      						->toHtml();

      				$result['output'] = $block;
      			}else{
      				$result['output'] = 0;
      			}

      			$status = 1;
      			$result['status'] = $status;
      			$response = $this->resultFactory->create(\Magento\Framework\Controller\ResultFactory::TYPE_JSON);
      			$response->setData($result);

      			return $response;

        } catch (\Magento\Framework\Exception\LocalizedException $e) {
            $this->messageManager->addException(
                $e,
                __('%1', $e->getMessage())
            );
        } catch (\Exception $e) {
            $this->messageManager->addException($e, __('error.'));
        }
        /*cart page*/
        $this->getResponse()->setRedirect('/checkout/cart/');
    }

	/**
     * Returns cart url
     *
     * @return string
     */
    private function getCartUrl()
    {
        return $this->_url->getUrl('checkout/cart', ['_secure' => true]);
    }

    /**
     * Create json response
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function jsonResponse($response = '')
    {
        return $this->getResponse()->representJson(
            $this->jsonHelper->jsonEncode($response)
        );
    }
}
