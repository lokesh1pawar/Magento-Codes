var config = {
    map: {
        '*':{
            region_id_reload:'Plumtree_Ups/js/region_id_reload',
         }
        },
    shim:{
     'region_id_reload':{
      deps: ['jquery']
      }
     }
};