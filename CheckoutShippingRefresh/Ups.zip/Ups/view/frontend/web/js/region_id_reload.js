// define(["jquery", "jquery/ui", "domReady!","region_id_reload"],

// function($,dom,region_id_reload){

//     $('select[name="region_id"]').on('change', function(){    
//         alert($(this).val());    
//         // $("input[name='postcode']").trigger('change');
//     });
    
//     // $("select[name='region_id']").change(function(){

//     // alert("Inner");

//     //     $("input[name='postcode']").trigger('change');
//     // });
//     // alert("Add Custom Js");
// })


define([
    
    "jquery", "jquery/ui", "domReady!","region_id_reload",
    "Magento_Checkout/js/model/quote",
    "Magento_Checkout/js/model/shipping-rate-registry"],

function($,dom,region_id_reload, mainQuote, rateReg){

    jQuery('select[name="region_id"]').on('change', function(){ 

        var postcode =  $("input[name='postcode']").val();
        // console.log(postcode);
        $("input[name='postcode']").val('').trigger('change');
        $("input[name='postcode']").val(postcode).trigger('change');
        // $("#TIXXH28").trigger("change") ;
        // alert("hii");
    //     var address = mainQuote.shippingAddress();
    // rateReg.set(address.getKey(), null);
    // rateReg.set(address.getCacheKey(), null);
    // mainQuote.shippingAddress(address);
        
        // alert($(this).val());    
        // $("input[name='postcode']").trigger('change');
    });
    
//     $("select[name='region_id']").change(function(){

//     alert("Inner");

//         $("input[name='postcode']").trigger('change');
//     });
//     alert("Add Custom Js");
});
