<?php
namespace Plumtree\Ups\Plugin\Model;

class ShippingMethodManagement
{
    protected $logger;
    protected $checkoutSession;
    protected $request;

    public function __construct(
        \Magento\Checkout\Model\Session $checkoutSession,
        \Psr\Log\LoggerInterface $logger,
        \Magento\Framework\App\Request\Http $request
    ) {
        $this->checkoutSession = $checkoutSession;
        $this->request = $request;
        $this->logger = $logger;
    }

    public function afterEstimateByExtendedAddress($shippingMethodManagement, $output)
    {
        return $this->filterOutput($output);
    }

    public function afterEstimateByAddressId($shippingMethodManagement, $output)
    {
        return $this->filterOutput($output);
    }

    private function filterOutput($output)
    {
        $writer = new \Zend_Log_Writer_Stream(BP . '/var/log/freeshipping.log');
        $logger = new \Zend_Log();
        $logger->addWriter($writer);
        $methods = [];
        $quoteId = $this->checkoutSession->getQuote()->getId();
        $isFreeShipping = false;
        foreach ($output as $shippingMethod) {
            if($shippingMethod->getCarrierCode() == 'freeshipping'){
              $isFreeShipping = true;
              break;
            }
        }
        if($isFreeShipping){
          foreach ($output as $shippingMethod) {
              if($shippingMethod->getCarrierCode() == 'freeshipping' && $shippingMethod->getMethodCode() == 'freeshipping'){
                $logger->info("UPS ground removed as freeshipping available for Quote: ".$quoteId);
              }else{
                $methods[] = $shippingMethod;
              }
          }
        }
        if (count($methods) > 0) {
            $logger->info("Custom collection returned");
            return $methods;
        }
        $logger->info("Default collection returned");
        return $output;
    }
}
