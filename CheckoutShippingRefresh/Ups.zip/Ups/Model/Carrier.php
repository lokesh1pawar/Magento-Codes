<?php

namespace Plumtree\Ups\Model;

use Magento\Quote\Model\Quote\Address\RateResult\Error;
use Magento\Quote\Model\Quote\Address\RateRequest;
use Magento\Shipping\Model\Carrier\AbstractCarrierOnline;
use Magento\Shipping\Model\Carrier\CarrierInterface;
use Magento\Shipping\Model\Rate\Result;
use Magento\Shipping\Model\Simplexml\Element;
use Magento\Ups\Helper\Config;
use Magento\Framework\Xml\Security;

class Carrier extends \Magento\Ups\Model\Carrier
{
   /* used objManager here starts

    public function objectManager(){
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        return $objectManager;
    }
    public function cartQuote(){
        $objectManager = $this->objectManager();

        $cart = $objectManager->get('\Magento\Checkout\Model\Cart');
        $cartQuote = $cart->getQuote();
        return $cartQuote;
    } */

    public function regionStateCode(){
        $regionId = $this->_request->getDestRegionId();
        $region = $this->_regionFactory->create()->load($regionId);
        $state_code = $region->getCode();

        return $state_code;
    }
    /*used objManager here ends*/

    /**
     * Collect and get rates/errors
     *
     * @param RateRequest $request
     * @return  Result|Error|bool
     */
    public function collectRates(RateRequest $request)
    {
        $this->setRequest($request);
        if (!$this->canCollectRates()) {
            return $this->getErrorMessage();
        }

        $this->setRequest($request);
        $this->_result = $this->_getQuotes();
        /* $this->_updateFreeMethodQuote($request);

            $cartQuote = $this->cartQuote();

            $discountAmount =  $cartQuote->getShippingAddress()->getData('discount_amount'); */

        $subtotal = $this->_request->getPackageValue();
        $freeShippingThresholdVal = $this->getConfigData('free_shipping_subtotal'); /*freeshipping Threshold Value*/

        /*$discountAmount = abs($discountAmount);

        $newSubTotalVal = $subtotal - $discountAmount; */
        $newSubTotalVal = $subtotal;
        $allowPriceChange = false;
        if($newSubTotalVal < $freeShippingThresholdVal){
            $allowPriceChange = true;
        }

        /*if $newSubTotalVal < $freeShippingThresholdVal
        allow free method ground shipping to be enabled at checkout regardless of matching items selection from admin*/
        if($this->getConfigData('free_method') != 'GND' && $allowPriceChange != true){
            $this->_updateFreeMethodQuote($request);
        }

        return $this->getResult();
    }

    /**
     * Prepare shipping rate result based on response
     *
     * @param string $response
     * @return Result
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     */
    protected function _parseCgiResponse($response)
    {
        $costArr = [];
        $priceArr = [];
        if (strlen(trim($response)) > 0) {
            $rRows = explode("\n", $response);
            $allowedMethods = explode(",", (string)$this->getConfigData('allowed_methods'));
            foreach ($rRows as $rRow) {
                $row = explode('%', $rRow);
                switch (substr($row[0], -1)) {
                    case 3:
                    case 4:
                        if (in_array($row[1], $allowedMethods)) {
                            $responsePrice = $this->_localeFormat->getNumber($row[8]);
                            $costArr[$row[1]] = $responsePrice;
                            $priceArr[$row[1]] = $this->getMethodPrice($responsePrice, $row[1]);
                        }
                        break;
                    case 5:
                        $errorTitle = $row[1];
                        $message = __(
                            'Sorry, something went wrong. Please try again or contact us and we\'ll try to help.'
                        );
                        $this->_logger->debug($message . ': ' . $errorTitle);
                        break;
                    case 6:
                        if (in_array($row[3], $allowedMethods)) {
                            $responsePrice = $this->_localeFormat->getNumber($row[10]);
                            $costArr[$row[3]] = $responsePrice;
                            $priceArr[$row[3]] = $this->getMethodPrice($responsePrice, $row[3]);
                        }
                        break;
                    default:
                        break;
                }
            }
            asort($priceArr);
        }

        $result = $this->_rateFactory->create();

        if (empty($priceArr)) {
            $error = $this->_rateErrorFactory->create();
            $error->setCarrier('ups');
            $error->setCarrierTitle($this->getConfigData('title'));
            $error->setErrorMessage($this->getConfigData('specificerrmsg'));
            $result->append($error);
        } else {
            foreach ($priceArr as $method => $price) {
                $rate = $this->_rateMethodFactory->create();
                $rate->setCarrier('ups');
                $rate->setCarrierTitle($this->getConfigData('title'));
                $rate->setMethod($method);
                $methodArray = $this->configHelper->getCode('method', $method);
                $rate->setMethodTitle($methodArray);
                $rate->setCost($costArr[$method]);
                //$rate->setPrice($price);

                $state_code = $this->regionStateCode();

                /*condition to remove ground option for outside of 50 states of U.S*/
                if($methodArray == 'Ground'){
	                if($state_code=="PR" || $state_code=="GU" || $state_code=="AS" || $state_code=="AE" || $state_code=="AA" || $state_code=="AP" || $state_code=="FM" || $state_code=="MH" || $state_code=="MP" || $state_code=="PW" || $state_code=="VI" || $state_code=="AK" || $state_code=="HI")
                    {
                        continue;
                    }
                }
               /* condition to remove ground option for outside of 50 states of U.S Ends

                  $cartQuote = $this->cartQuote();

                  $discountAmount =  $cartQuote->getShippingAddress()->getData('discount_amount'); */

                $subtotal = $this->_request->getPackageValue();
                $freeShippingThresholdVal = $this->getConfigData('free_shipping_subtotal'); //freeshipping Threshold Value

                /* $discountAmount = abs($discountAmount); */ 

                /* $newSubTotalVal = $subtotal - $discountAmount; */
                $newSubTotalVal = $subtotal;
                $allowPriceChange = false;
                if($newSubTotalVal < $freeShippingThresholdVal){
                    $allowPriceChange = true;
                }

                $upsGroundCustomPriceAdmin = 'ups_ground_shipping/general/ground_price'; //ground shipping custom value if freeshipping not applied

                $upsGroundCustomPrice = $this->_scopeConfig->getValue($upsGroundCustomPriceAdmin,
                    \Magento\Store\Model\ScopeInterface::SCOPE_STORE,
                    $this->_request->getStoreId()
                );
				
				if($methodArray == 'Ground'){
                    $price = 0;
                    $rate->setPrice($price);
                }

                if($methodArray == 'Ground' && $allowPriceChange == true && $upsGroundCustomPrice != ''){
                    $rate->setPrice($upsGroundCustomPrice);
                }else{
                    $rate->setPrice($price);
                }
                $result->append($rate);
            }
        }

        return $result;
    }
}
