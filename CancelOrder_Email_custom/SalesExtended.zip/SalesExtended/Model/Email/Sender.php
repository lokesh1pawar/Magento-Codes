<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Plumtree\SalesExtended\Model\Email;

use Magento\Framework\DataObject;

/**
 * Email notification sender for Cancellation.
 *
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 */
class Sender extends \Magento\Sales\Model\Order\Email\Sender
{

    const ORDER_CANCEL_TEMPLATE = 'order_cancel_template';
    /**
     * @var \Magento\Payment\Helper\Data
     */
    private $paymentHelper;

    /**
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    private $globalConfig;

    private $frontendAreaCode = 'frontend';

    /**
     * @var \Magento\Framework\Mail\Template\TransportBuilder
     */
    private $transportBuilder;

    /**
     * @param \Magento\Sales\Model\Order\Email\Container\Template $templateContainer
     * @param \Magento\Sales\Model\Order\Email\Container\CreditmemoIdentity $identityContainer
     * @param \Magento\Sales\Model\Order\Email\SenderBuilderFactory $senderBuilderFactory
     * @param \Psr\Log\LoggerInterface $logger
     * @param \Magento\Sales\Model\Order\Address\Renderer $addressRenderer
     * @param \Magento\Payment\Helper\Data $paymentHelper
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $globalConfig
     */
    public function __construct(
        \Magento\Sales\Model\Order\Email\Container\Template $templateContainer,
        \Magento\Sales\Model\Order\Email\Container\CreditmemoIdentity $identityContainer,
        \Magento\Sales\Model\Order\Email\SenderBuilderFactory $senderBuilderFactory,
        \Psr\Log\LoggerInterface $logger,
        \Magento\Sales\Model\Order\Address\Renderer $addressRenderer,
        \Magento\Framework\Mail\Template\TransportBuilder $transportBuilder,
        \Magento\Payment\Helper\Data $paymentHelper,
        \Magento\Framework\App\Config\ScopeConfigInterface $globalConfig
    ) {
        parent::__construct(
            $templateContainer,
            $identityContainer,
            $senderBuilderFactory,
            $logger,
            $addressRenderer
        );
        $this->transportBuilder = $transportBuilder;
        $this->paymentHelper = $paymentHelper;
        $this->globalConfig = $globalConfig;
    }

    /**
     * Sends order cancel email to the customer.
     */
    public function sendOrderCancelNotification(\Magento\Sales\Api\Data\OrderInterface $order)
    {
        try {
            $customerName = $order->getCustomerFirstname()." ".$order->getCustomerLastname();
            $customerEmail = $order->getCustomerEmail();
            $senderName = $this->globalConfig->getValue('trans_email/ident_sales/name', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
            $senderEmail = $this->globalConfig->getValue('trans_email/ident_sales/email', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
            $sender = [
                'name' => $senderName,
                'email' => $senderEmail,
            ];
            // $writer = new \Zend_Log_Writer_Stream(BP . '/var/log/custom_email.log');
            // $logger = new \Zend_Log();
            // $logger->addWriter($writer);
            // $logger->info("formattedShippingAddress' => $this->getFormattedShippingAddress($order)");

            $transport = [
                'order' => $order,
                'order_id' => $order->getId(),
                'billing' => $order->getBillingAddress(),
                'payment_html' => $this->getPaymentHtml($order),
                'store' => $order->getStore(),
                'formattedShippingAddress' => $this->getFormattedShippingAddress($order),
                'formattedBillingAddress' => $this->getFormattedBillingAddress($order),
                'created_at_formatted' => $order->getCreatedAtFormatted(2),
                'order_data' => [
                    'customer_name' => $order->getCustomerName(),
                    'is_not_virtual' => $order->getIsNotVirtual(),
                ]
            ];
            $transportObject = new DataObject($transport);

            $transportBuilder = $this->transportBuilder->setTemplateIdentifier(self::ORDER_CANCEL_TEMPLATE)
                  ->setTemplateOptions(['area' => $this->frontendAreaCode, 'store' => $order->getStore()->getId()])
                  ->setTemplateVars($transportObject->getData())
                  ->setFrom($sender)
                  ->setReplyTo($senderEmail, $senderName)
                  ->addTo($customerEmail, $customerName);

            $transport = $transportBuilder->getTransport();
            $transport->sendMessage();
            $this->logger->info("Cancel order email sent for #".$order->getIncrementId());
            return true;
        } catch (\Exception $e) {
            $this->logger->critical($e);
            return false;
        }
        return false;
    }

    /**
     * Returns payment info block as HTML.
     *
     * @param \Magento\Sales\Api\Data\OrderInterface $order
     *
     * @return string
     * @throws \Exception
     */
    private function getPaymentHtml(\Magento\Sales\Api\Data\OrderInterface $order)
    {
        return $this->paymentHelper->getInfoBlockHtml(
            $order->getPayment(),
            $this->identityContainer->getStore()->getStoreId()
        );
    }
}
