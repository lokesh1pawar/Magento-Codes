<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Plumtree\SalesExtended\Observer\Order;

class CancelAfter implements \Magento\Framework\Event\ObserverInterface
{
    private $emailSender;

    public function __construct(
      \Plumtree\SalesExtended\Model\Email\Sender $emailSender
    ){
      $this->emailSender = $emailSender;
    }

    /**
     * Execute observer
     *
     * @param \Magento\Framework\Event\Observer $observer
     * @return void
     */
    public function execute(
        \Magento\Framework\Event\Observer $observer
    ) {
        $order = $observer->getEvent()->getOrder();
        $this->emailSender->sendOrderCancelNotification($order);
    }
}
