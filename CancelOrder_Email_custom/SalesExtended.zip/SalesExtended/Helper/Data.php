<?php 

namespace Plumtree\SalesExtended\Helper;

use \Magento\Framework\App\Helper\AbstractHelper;
use Magento\Framework\Mail\Template\TransportBuilder;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Store\Model\StoreManagerInterface;

/**
 * Data Helper
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 */
class Data extends AbstractHelper
{
    private $transportBuilder;

    protected $scopeConfig;

    private $storeManager;

    /**
     * @param \Magento\Framework\App\Helper\Context $context
     * @param \Magento\Framework\Mail\Template\TransportBuilder $transportBuilder
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     */
    public function __construct(
        \Magento\Framework\App\Helper\Context $context,
        \Magento\Framework\Mail\Template\TransportBuilder $transportBuilder,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Store\Model\StoreManagerInterface $storeManager
    ) {
        parent::__construct($context);
        $this->transportBuilder = $transportBuilder;
        $this->scopeConfig = $scopeConfig;
        $this->storeManager = $storeManager;
    }
   
    /**
     * Send shipment failed notification
     * 
     * @param string $orderId
     * @param string $error
     * @return void
     */
    public function sendNotification($orderId, $error): void
    {
        $sender = [
            'name' => $this->scopeConfig->getValue('trans_email/ident_custom1/name',\Magento\Store\Model\ScopeInterface::SCOPE_STORE),
            'email' => $this->scopeConfig->getValue('trans_email/ident_custom1/email',\Magento\Store\Model\ScopeInterface::SCOPE_STORE)
        ];

        $sentToEmail = $this->scopeConfig->getValue('trans_email/ident_general/email',\Magento\Store\Model\ScopeInterface::SCOPE_STORE);             
        $sentToName = $this->scopeConfig->getValue('trans_email/ident_general/name',\Magento\Store\Model\ScopeInterface::SCOPE_STORE);
        

        // $sender = [
        //     'name' => 'Administrator',
        //     'email' => 'ecommerce@everlast.com'
        // ];  
        // $sentToEmail = 'pravin@plumtreewebsolutions.com';             
        // $sentToName = 'Naim Munshi';


        $transport = $this->transportBuilder
            ->setTemplateIdentifier('shipment_fail_notification_template')
            ->setTemplateOptions(
                [
                    'area' => 'frontend',
                    'store' => $this->storeManager->getStore()->getId()
                ]
                )
                ->setTemplateVars([
                    'order_id'  => $orderId,
                    'error'  => $error
                ])
                ->setFromByScope($sender)
                ->addTo($sentToEmail,$sentToName)
                ->getTransport();
                 
                $transport->sendMessage();
    }
}
