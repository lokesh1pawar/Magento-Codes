<?php
Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Lokesh_CustomAttr',
    __DIR__
);
