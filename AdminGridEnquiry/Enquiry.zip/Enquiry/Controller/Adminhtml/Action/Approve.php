<?php
namespace Thecoachsmb\Enquiry\Controller\Adminhtml\Action;

use Magento\Contact\Model\MailInterface;

class Approve extends \Magento\Backend\App\Action
{

    private $mail;
    private $_resultFactory; 

    const ADMIN_RESOURCE = 'Thecoachsmb_Enquiry::approve';

    const PAGE_TITLE = 'Approved';

    /**
     * @var \Magento\Framework\View\Result\PageFactory
     */
    protected $_pageFactory;

    /**
     * @param \Magento\Backend\App\Action\Context $context
     */
    public function __construct(
       \Magento\Backend\App\Action\Context $context,
       MailInterface $mail,
       \Magento\Framework\Controller\ResultFactory $resultFactory, 
       \Magento\Framework\View\Result\PageFactory $pageFactory
       
    )
    {
        $this->_pageFactory = $pageFactory;
        $this->_resultFactory = $resultFactory; 

        $this->mail = $mail;
        return parent::__construct($context);
    }

    /**
     * Index action
     *
     * @return \Magento\Framework\View\Result\Page
     */
    public function execute()
    {
    
        $id = $this->getRequest()->getParam('id');
        $model = $this->_objectManager->create('Thecoachsmb\Enquiry\Model\Enquiry')->load($id);
        if ($model->getId()) {
            try {
                $model->setData('status', 'Approved');
                $model->save();
                
                // Send email to the user
                $this->sendEmailToUser($model->getEmail());

                $this->messageManager->addSuccess(__('Enquiry has been approved.'));
            } catch (LocalizedException $e) {
                $this->messageManager->addError($e->getMessage());
            } catch (\Exception $e) {
                $this->messageManager->addException($e, __('Something went wrong while approving the enquiry.'));
            }
        

        $resultRedirect = $this->_resultFactory->create(\Magento\Framework\Controller\ResultFactory::TYPE_REDIRECT);
        $resultRedirect->setPath('enquirygrid/index/go'); 
        return $resultRedirect; 
    }
}

    /**
     * Send email to the user
     *
     * @param string $email
     * @return void
     * @throws MailException
     */
    protected function sendEmailToUser($email)
    {
        $receiverInfo = [
            'name' => 'User',
            'email' => $email,
        ];

        $templateId = 'your_email_template_id';

        $templateVars = [
            'message' => 'Your enquiry has been approved by the admin.',
        ];

        $senderInfo = [
            'name' => 'Admin',
            'email' => 'admin@example.com',
        ];

        try {
            $this->mail->send($templateId, $senderInfo, $receiverInfo, $templateVars);
        } catch (MailException $e) {
            throw new MailException(__('Something went wrong while sending email.'));
        }
    }

    // private function sendEmail($post)
    // {
    //     $this->mail->send(
    //         $post['name'],
    //         $post['email'],
    //         $post['phone'],
    //         ['data' => new DataObject($post)]
    //     );
    // }

    // public function sendEmail()
    // {
    //     try {
    //         $this->inlineTranslation->suspend();
    //         $sender = [
    //             'name' => $this->escaper->escapeHtml('Test'),
    //             'email' => $this->escaper->escapeHtml('lokesh1pawar@gmail.com'),
    //         ];
    //         $transport = $this->transportBuilder
    //             ->setTemplateIdentifier('email_demo_template')
    //             ->setTemplateOptions(
    //                 [
    //                     'area' => \Magento\Framework\App\Area::AREA_FRONTEND,
    //                     'store' => \Magento\Store\Model\Store::DEFAULT_STORE_ID,
    //                 ]
    //             )
    //             ->setTemplateVars([
    //                 'templateVar'  => 'My Topic',
    //             ])
    //             ->setFrom($sender)
    //             ->addTo('lokesh1pawar@gmail.com')
    //             ->getTransport();
    //         $transport->sendMessage();
    //         $this->inlineTranslation->resume();
    //     } catch (\Exception $e) {
    //         // $this->logger->debug($e->getMessage());
    //     }
    // }

    /**
     * Is the user allowed to view the page.
    *
    * @return bool
    */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed(static::ADMIN_RESOURCE);
    }
}
