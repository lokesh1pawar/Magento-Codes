<?php
namespace Thecoachsmb\Enquiry\Controller\Index;

// use Magento\Framework\Validator\EmailAddress;
use Magento\Framework\Validator\NotEmpty;
use Magento\Framework\App\Request\DataPersistorInterface;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\App\ObjectManager;
use Magento\Contact\Model\MailInterface;
use Magento\Framework\App\Action\HttpPostActionInterface as HttpPostActionInterface;
use Magento\Contact\Model\ConfigInterface;
use Magento\Framework\App\Action\Context;
use Magento\Framework\Controller\Result\Redirect;
use Magento\Framework\DataObject;


class Save extends \Magento\Framework\App\Action\Action
{
     protected $_pageFactory;
     protected $_enquiryFactory;
     protected $dataPersistor;
     private $mail;
 
     public function __construct(
          \Magento\Framework\App\Action\Context $context,
          \Magento\Framework\View\Result\PageFactory $pageFactory,
          \Thecoachsmb\Enquiry\Model\EnquiryFactory $enquiryFactory,
          MailInterface $mail,
          DataPersistorInterface $dataPersistor

     ){
          $this->_pageFactory = $pageFactory;
          $this->_enquiryFactory = $enquiryFactory;
          $this->dataPersistor = $dataPersistor;
          $this->mail = $mail;
          return parent::__construct($context);
     }
 

     public function execute()
     {
          // if ($this->getRequest()->isPost()) {
          //                $input = $this->getRequest()->getPostValue();
          //                $postData = $this->_enquiryFactory->create();
                       
          //                if ($this->validateFormData($postData)) {
          //                     // $this->sendEmail($postData);
          //                     $this->messageManager->addSuccessMessage("Data added successfully!");
          //                     $postData->setData($input)->save();
          //                     return $this->_redirect('enquiryform/index/index');
          //                } else {
          //                     $this->messageManager->addErrorMessage("Invalid form data");
          //                     return $this->_redirect('enquiryform/index/index');
          //                }
          //           }

         if (!$this->getRequest()->isPost()) {
             return $this->resultRedirectFactory->create()->setPath('*/*/');
         }
         try {
          //    $this->sendEmail($this->validatedParams());
          // echo "Lokesh";
          // $input = $this->validatedParams();
          $input = $this->sendEmail($this->validatedParams());
          // print_r($input);
          // exit();
           if($input){

            $postData = $this->_enquiryFactory->create();

          //    $this->validatedParams();
             $postData->setData($input)->save();
             $this->messageManager->addSuccessMessage(
                 __('Thanks for contacting us with your comments and questions. We\'ll respond to you very soon.')
             );
             $this->dataPersistor->clear('contact_eq');
          }
         } catch (LocalizedException $e) {
             $this->messageManager->addErrorMessage($e->getMessage());
             $this->dataPersistor->set('contact_eq', $this->getRequest()->getParams());
         } catch (\Exception $e) {
             $this->logger->critical($e);
             $this->messageManager->addErrorMessage(
                 __('An error occurred while processing your form. Please try again later.')
             );
             $this->dataPersistor->set('contact_eq', $this->getRequest()->getParams());
         }
         return $this->resultRedirectFactory->create()->setPath('enquiryform/index/index');
     }
 
     private function sendEmail($post)
     {
         $this->mail->send(
             $post['email'],
             ['data' => new DataObject($post)]
         );
     }

     private function validatedParams()
     {
          // echo "Hiiii";
          $request = $this->getRequest();
          // print_r($request->getParams());
          //    exit;
          if (trim($request->getParam('name')) == '') {
               throw new LocalizedException(__('Enter the Name and try again.'));
          }
          if (false === \strpos($request->getParam('email'), '@')) {
               throw new LocalizedException(__('The email address is invalid. Verify the email address and try again.'));
          }
          if (trim($request->getParam('phone')) == '') {
               throw new LocalizedException(__('Enter the Phone and try again.'));
          }
          
          return $request->getParams();
     }
     
     // public function execute()
     // {
     //      if ($this->getRequest()->isPost()) {
     //           $input = $this->getRequest()->getPostValue();
     //           $postData = $this->_enquiryFactory->create();

     //           // if( $this->validateFormData($postData) ){
     //           //      $postData->load($id);
     //           //      $postData->addData($input);
     //           //      $postData->setId($id);
     //           //      $postData->save();
     //           // }
               
     //           // else{
     //           //      $this->messageManager->addSuccessMessage("Data added successfully!");
     //           //      $postData->setData($input)->save();
     //           //      return $this->_redirect('enquiryform/index/index');
     //           // }
              
         
               
               
     //           if ($this->validateFormData($postData)) {
     //                // $this->sendEmail($postData);
     //                $this->messageManager->addSuccessMessage("Data added successfully!");
     //                $postData->setData($input)->save();
     //                return $this->_redirect('enquiryform/index/index');
     //           } else {
     //                $this->messageManager->addErrorMessage("Invalid form data");
     //                return $this->_redirect('enquiryform/index/index');
     //           }
     //      }

     
     // }

     /**
      * Validate the form data
      * 
      * @param array $postData
      * @return bool
      */
     // protected function validateFormData($postData)
     // {
     //      $notEmptyValidator = new NotEmpty();
     //      // $emailValidator = new EmailAddress();
     //      $isValid = true;
          
     //      if (!$notEmptyValidator->isValid($postData['name'])) {
     //           $this->messageManager->addErrorMessage("Name is Missing");
     //           $isValid = false;
     //      }
          
     //      if (!$notEmptyValidator->isValid($postData['email'])) {
     //           $this->messageManager->addErrorMessage("Email is Missing");
     //           $isValid = false;
     //      }
          
     //      if (!$notEmptyValidator->isValid($postData['phone'])) {
     //           $this->messageManager->addErrorMessage("Phone is Missing");
     //           $isValid = false;      
     //          }
          
     //      return $isValid;
     // }

}