<?php
namespace Thecoachsmb\Enquiry\Model\ResourceModel\Enquiry;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    protected $_idFieldName = 'id';
    protected $_eventPrefix = 'thecoachsmb_enquiry_collection';
    protected $_eventObject = 'thecoachsmb_collection';

    /**
     * Define the resource model & the model.
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Thecoachsmb\Enquiry\Model\Enquiry', 'Thecoachsmb\Enquiry\Model\ResourceModel\Enquiry');
    }
}
