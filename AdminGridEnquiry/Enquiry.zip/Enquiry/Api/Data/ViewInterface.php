<?php
namespace Thecoachsmb\Enquiry\Api\Data;

interface ViewInterface
{
    /**#@+
     * Constants for keys of data array. Identical to the name of the getter in snake case
     */
    const ID            = 'id';
    const NAME          = 'name';
    const EMAIL         = 'email';
    const PHONE         = 'phone';
    const STATUS        = 'status';
    /**#@-*/


    /**
     * Get Name
     *
     * @return string|null
     */
    public function getName();

    /**
     * Get Email
     *
     * @return string|null
     */
    public function getEmail();

    /**
     * Get Phone
     *
     * @return string|null
     */
    public function getPhone();

    /**
     * Get Status
     *
     * @return string|null
     */
    public function getStatus();

    /**
     * Get ID
     *
     * @return int|null
     */
    public function getId();

    /**
     * Set Name
     *
     * @param string $name
     * @return $this
     */
    public function setName($name);

    /**
     * Set Email
     *
     * @param string $email
     * @return $this
     */
    public function setEmail($email);

    /**
     * Set Phone
     *
     * @param int $phone
     * @return $this
     */
    public function setPhone($phone);

    /**
     * Set Status
     *
     * @param int $status
     * @return $this
     */
    public function setStatus($status);

    /**
     * Set ID
     *
     * @param int $id
     * @return $this
     */
    public function setId($id);
}