<?php
namespace Thecoachsmb\Enquiry\Block;

use Magento\Framework\View\Element\Template;

class Index extends \Magento\Framework\View\Element\Template
{
    protected $_pageFactory;
    protected $_postLoader;
    /**
     * @param \Magento\Framework\View\Element\Template\Context $context
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Magento\Framework\View\Result\PageFactory $pageFactory,
        array $data = []
    ) {
        $this->_pageFactory = $pageFactory;
        return  parent::__construct($context, $data);
    }

    public function execute()
    {
         return $this->_pageFactory->create();
    }
}

