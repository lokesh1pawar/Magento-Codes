<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Thecoachsmb\Enquiry\Plugin;
use Magento\Framework\Controller\Result\Redirect;
// use Magento\Framework\App\Action\Context;
use Magento\Framework\Controller\ResultFactory;


class LoginPost
{
    protected $resultFactory;

    public function __construct(
        \Magento\Framework\Controller\ResultFactory $resultFactory,
        \Magento\Framework\App\Action\Context $context
    )
    {
       $this->resultFactory = $resultFactory;
    
    //    parent::__construct($context);
    }

    public function afterExecute(\Magento\Customer\Controller\Account\LoginPost $subject, $result){
        return $this->resultRedirectFactory->create()->setPath('contact/index');
    }
}
// $resultRedirect->setUrl($this->_redirect->getRefererUrl());
//         return $resultRedirect;
    // }