<?php
 
namespace Plumtree\Careers\Controller\Index;
 
use Magento\Framework\App\Action\Context;
use Magento\Framework\Message\ManagerInterface;
use Magento\Framework\Filesystem;
use Magento\MediaStorage\Model\File\UploaderFactory;
use Magento\Catalog\Model\Session as CatalogSession;
 
class Sendemail extends \Magento\Framework\App\Action\Action
{

    protected $_catalogSession;

    // protected $_storeManager;
    protected $storeManager;


    /**
     * @var \Magento\Framework\Mail\Template\TransportBuilder
     */
    protected $_transportBuilder;

    /**
     * @var \Magento\Framework\Message\ManagerInterface
     */

    protected $messageManager;

    /**
     * @var \Magento\Framework\Filesystem $filesystem
     */
    protected $filesystem;

    /**
     * @var \Magento\MediaStorage\Model\File\UploaderFactory $fileUploader
     */
    protected $fileUploader;

    protected $_resultPageFactory;

    /**
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    protected $scopeConfig;

    const XML_NOTIFY_VALUE = 'trans_email/general/careers_email_message';
 
    public function __construct(Context $context,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        CatalogSession $catalogSession,
        \Magento\Store\Model\StoreManagerInterface $storeManager, 
        \Magento\Framework\Mail\Template\TransportBuilder $transportBuilder,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        ManagerInterface $messageManager,
        Filesystem $filesystem,
        UploaderFactory $fileUploader
    )
    {
        $this->scopeConfig        = $scopeConfig;
        $this->_catalogSession    = $catalogSession;
        $this->storeManager = $storeManager;
        $this->_transportBuilder  = $transportBuilder;
        $this->filesystem         = $filesystem;
        $this->fileUploader       = $fileUploader;
        $this->messageManager     = $messageManager;
        $this->_resultPageFactory = $resultPageFactory;
        $this->mediaDirectory     = $filesystem->getDirectoryWrite(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA);
        parent::__construct($context);
    }

     public function getCatalogSession() 
    {
        return $this->_catalogSession;
    }

 
    public function execute()
    {

        // this folder will be created inside "pub/media" folder
        $yourFolderName = 'careers-resumes/';
 
        // "my_custom_file" is the HTML input file name
        $yourInputFileName = 'careers-resume';
 
        try{
            $postValues = $this->getRequest()->getPost();
            $file = $this->getRequest()->getFiles($yourInputFileName);
            $fileName = ($file && array_key_exists('name', $file)) ? $file['name'] : null;


            if ($file && $fileName) {
                $target = $this->mediaDirectory->getAbsolutePath($yourFolderName);        
                
                /** @var $uploader \Magento\MediaStorage\Model\File\Uploader */
                $uploader = $this->fileUploader->create(['fileId' => $yourInputFileName]);
                
                // set allowed file extensions
                $uploader->setAllowedExtensions(['doc', 'docx', 'pdf']);
                
                // allow folder creation
                $uploader->setAllowCreateFolders(true);
 
                // rename file name if already exists 
                $uploader->setAllowRenameFiles(true);
                
                $fileName = $fileName;
                $fileExt = strtolower(substr(strrchr($fileName, ".") ,1));
                $fileNamewoe = rtrim($fileName, $fileExt);
                $fileName = $fileNamewoe . date("m-d-Y") . '-' .date("h:i:sa") . '.' . $fileExt;
                $fileType = $file['type'];

                $result = $uploader->save($target,$fileName);
                
                $filePath = $result['path'].$result['file'];


                if ($result['file']) {
                    $applicantName = $postValues['name'];
                    $applicantEmail = $postValues['email'];
                    $applicantTelephone = $postValues['telephone_number'];
                    $applicantPositionAppliedFor = $postValues['position'];
    
                    $sender = [
                        'name' => $applicantName,
                        'email' => $applicantEmail
                    ];

                    $templateVars = [
                            'store' => $this->storeManager->getStore(),
                            'applicant_name' => $applicantName,
                            'applicant_email' => $applicantEmail,
                            'applicant_phone' => $applicantTelephone,
                            'applicant_position' => $applicantPositionAppliedFor
                        ];

                    $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
                    $notifyEmail = $this->scopeConfig->getValue(self::XML_NOTIFY_VALUE, $storeScope);                        

                    $transport = $this->_transportBuilder->
                    setTemplateIdentifier('careerspositions_email_template')
                    ->setTemplateOptions(
                        [
                            'area' => 'frontend',
                            'store' => $this->storeManager->getStore()->getId()
                        ]
                    )
                    ->setTemplateVars($templateVars)
                    ->setFromByScope($sender)
                    // you can config general email address in Store -> Configuration -> General -> Store Email Addresses
                    ->addTo($notifyEmail, 'Receiver Name')
                    
                    ->addAttachment(file_get_contents($filePath), $fileName, $fileType)

                    ->getTransport();

                    try {
                        $transport->sendMessage();
                        $this->getCatalogSession()->setMySession($applicantEmail);

                        $this->_redirect('careers/index/success'); 
                        return;
                    }
                    catch(\Exception $e) {
                        $this->messageManager->addError('Unable to send email. Please check that the details you have entered are correct.');
                        $this->_redirect('careers');
                    }
                }
            }
        } catch (\Exception $e) {
            $this->messageManager->addError($e->getMessage());
        }        
 
        $this->_redirect('careers');
        
    }

}