<?php

namespace Plumtree\Careers\Model\ResourceModel\Careers;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

/**
 * Contact Resource Model Collection
 *
 * @author      Magento.Inc
 */
class Collection extends AbstractCollection
{
    /**
     * Initialize resource collection
     *
     * @return void
     */

    /**
     * @var string
     */
    protected $_idFieldName = 'id';


    public function _construct()
    {
        $this->_init('Plumtree\Careers\Model\Careers', 'Plumtree\Careers\Model\ResourceModel\Careers');
    }
}