<?php
namespace Plumtree\Careers\Model\Mail\Template;

class AddEmailAttachemnt extends \Magento\Framework\Mail\Template\TransportBuilder
{
    
    public function addAttachment($content, $fileName, $fileType)
    {
        $attachmentPart = new \Zend_Mime_Part($content);
        $attachmentPart->type = $fileType;
        $attachmentPart->filename = $fileName;
        $attachmentPart->disposition = \Zend_Mime::DISPOSITION_ATTACHMENT;
        $attachmentPart->encoding = \Zend_Mime::ENCODING_BASE64;
        return $this;
    }

    protected function prepareMessage()
    {
        parent::prepareMessage();
        return $this;
    }
}