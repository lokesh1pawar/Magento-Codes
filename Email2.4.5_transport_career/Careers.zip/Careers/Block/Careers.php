<?php
namespace Plumtree\Careers\Block;

use Magento\Catalog\Model\Session as CatalogSession;
use Plumtree\Careers\Model\CareersFactory;

class Careers extends \Magento\Framework\View\Element\Template
{
    protected $_modelCareersFactory;

	protected $_catalogSession;

	protected $response;

	public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        CareersFactory $modelCareersFactory,
        \Magento\Framework\App\Response\Http $response,
       	CatalogSession $catalogSession,
        array $data = []
    )
    {    
        $this->_modelCareersFactory = $modelCareersFactory;
    	$this->response 		  = $response;
    	$this->_catalogSession    = $catalogSession;
        parent::__construct($context, $data);
    }

    public function getCareersPositions()
    {
        $resultPage = $this->_modelCareersFactory->create();
        $collection = $resultPage->getCollection()->addFieldToFilter(
            'status',
            array('eq' => 1)
        );
        return $collection;
    }


    public function getCatalogSession() 
    {
        return $this->_catalogSession;
    }

    public function getResponse() 
    {
        return $this->response;
    }

}