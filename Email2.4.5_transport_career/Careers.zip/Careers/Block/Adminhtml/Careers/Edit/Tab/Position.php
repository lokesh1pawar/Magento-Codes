<?php

namespace Plumtree\Careers\Block\Adminhtml\Careers\Edit\Tab;

use Magento\Backend\Block\Widget\Form\Generic;
use Magento\Backend\Block\Widget\Tab\TabInterface;

class Position extends Generic implements TabInterface
{

protected $_wysiwygConfig;

protected $_booleanOptions;

protected $_descriptionModel;

public function __construct(
    \Magento\Backend\Block\Template\Context $context,
    \Magento\Cms\Model\Wysiwyg\Config $wysiwygConfig,
    \Magento\Config\Model\Config\Source\Yesno $booleanOptions,
    \Magento\Framework\Registry $registry,
    \Magento\Framework\Data\FormFactory $formFactory,
    \Plumtree\Careers\Model\Careers $careersDescription,
    array $data = []
)
{
    $this->_wysiwygConfig = $wysiwygConfig;
    $this->_descriptionModel = $careersDescription;
    $this->_booleanOptions   = $booleanOptions;
    parent::__construct($context, $registry, $formFactory, $data);
}

protected function _prepareForm()
{
    $model = $this->_coreRegistry->registry('blog_post');

    $form = $this->_formFactory->create();

    $form->setHtmlIdPrefix('careers_');

    $id = $this->getRequest()->getParam('id');

    if($id){
        $fieldset = $form->addFieldset(
            'base_fieldset',
            ['legend' => __('Edit Position'), 'class' => 'fieldset-wide']
        );
    }else{
        $fieldset = $form->addFieldset(
            'base_fieldset',
            ['legend' => __('New Position'), 'class' => 'fieldset-wide']
        );
    }

    if ($model->getId()) {
        $fieldset->addField('id', 'hidden', ['name' => 'id']);
    }

    $fieldset->addField(
        'status',
        'select',
        [
            'name'  => 'status',
            'label' => __('Status'),
            'title' => __('Status'),
            'values' => $this->_booleanOptions->toOptionArray(),
            'required' => true
        ]
    );

    $fieldset->addField(
            'position',
            'text',
            [
                'name' => 'position',
                'label' => __('Position'),
                'title' => __('Position'),
                'required' => true
            ]
        );

        
    $fieldset->addField(
        'position_desc',
        'editor',
        [
            'name' => 'position_desc',
            'label' => __('Position Description'),
            'title' => __('Position Description'),
            'style' => 'height:36em',
            'wysiwyg' => true,
            'config' => $this->_wysiwygConfig->getConfig(),
            'required' => true
        ]
    );

    $form->setValues($model->getData());
    $this->setForm($form);

    return parent::_prepareForm();
}

/**
 * Return Tab label
 *
 * @return string
 * @api
 */
public function getTabLabel()
{
    return __('Careers Position');
}

/**
 * Return Tab title
 *
 * @return string
 * @api
 */
public function getTabTitle()
{
    return __('Careers Position');
}

/**
 * Can show tab in tabs
 *
 * @return boolean
 * @api
 */
public function canShowTab()
{
    return true;
}

/**
 * Tab is hidden
 *
 * @return boolean
 * @api
 */
public function isHidden()
{
    return false;
}
}