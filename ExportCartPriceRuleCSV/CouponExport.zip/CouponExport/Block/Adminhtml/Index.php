<?php
namespace Plumtree\CouponExport\Block\Adminhtml;

class Index extends \Magento\Backend\Block\Template
{
}
