<?php

namespace Plumtree\CouponExport\Controller\Adminhtml\Export;

class GridToCsv extends \Magento\Ui\Controller\Adminhtml\Export\GridToCsv
{
    const ADMIN_RESOURCE = 'My_AdvancedReport::advanced_invoice_report';
}