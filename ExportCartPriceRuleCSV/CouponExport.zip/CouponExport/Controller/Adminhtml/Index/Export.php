<?php
namespace Plumtree\CouponExport\Controller\Adminhtml\Index;

// use Magento\Backend\App\Action;
use Magento\Framework\App\ResponseInterface;
use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\Controller\ResultInterface;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\SalesRule\Model\ResourceModel\Rule\Collection;
use Magento\SalesRule\Model\ResourceModel\Rule\CollectionFactory as RuleCollectionFactory;
// use Magento\Framework\Stdlib\DateTime\TimezoneInterface;

 
/**
 * Class Export
 */
class Export extends \Magento\Framework\App\Action\Action
{
   /**
     * @var \Magento\Framework\App\Response\Http\FileFactory
     */
    protected $fileFactory;

    protected $ruleFactory;
 
    protected $ruleDataFactory;

    protected $ruleCollectionFactory;
    /**
     * @var \Magento\SalesRule\Model\RuleFactory
     */
    // protected $ruleFactory;
    // protected $_ruleCollection;
    private $objectManager;


    /**
     * @var \Magento\Framework\View\Result\LayoutFactory
     */
    protected $resultLayoutFactory;
    /**
     * @var \Magento\Framework\File\Csv
     */
    protected $csvProcessor;
    /**
     * @var \Magento\Framework\App\Filesystem\DirectoryList
     */
    protected $directoryList;
    /**
     * @param \Magento\Framework\App\Action\Context            $context
     * @param \Magento\Framework\App\Response\Http\FileFactory $fileFactory
     * @param \Magento\SalesRule\Model\RuleFactory             $ruleFactory
     * @param \Magento\Framework\View\Result\LayoutFactory     $resultLayoutFactory
     * @param \Magento\Framework\File\Csv                      $csvProcessor
     * @param \Magento\Framework\App\Filesystem\DirectoryList  $directoryList
     */
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\App\Response\Http\FileFactory $fileFactory,
        // \Magento\SalesRule\Model\RuleFactory $ruleFactory,
        // RuleCollection $ruleCollection,

        \Magento\Framework\View\Result\LayoutFactory $resultLayoutFactory,
        \Magento\Framework\File\Csv $csvProcessor,
        \Magento\SalesRule\Model\ResourceModel\Rule\CollectionFactory $ruleCollectionFactory,
        \Magento\SalesRule\Model\RuleFactory $ruleFactory,
        \Magento\SalesRule\Api\Data\RuleInterfaceFactory $ruleDataFactory,


        \Magento\Framework\ObjectManagerInterface $objectmanager,
        // RuleCollectionFactory $ruleCollectionFactory,

        \Magento\Framework\App\Filesystem\DirectoryList $directoryList
    ) {
        $this->fileFactory = $fileFactory;
        // $this->ruleFactory = $ruleFactory;
        // $this->_ruleCollection = $ruleCollection;
        $this->resultLayoutFactory = $resultLayoutFactory;
        $this->csvProcessor = $csvProcessor;
        $this->objectManager = $objectmanager;
        $this->ruleFactory = $ruleFactory;
        $this->ruleDataFactory = $ruleDataFactory;
        $this->ruleCollectionFactory = $ruleCollectionFactory;

        $this->directoryList = $directoryList;
        parent::__construct($context);
    }
    /**
     * CSV Create and Download
     *
     * @return ResponseInterface
     * @throws \Magento\Framework\Exception\FileSystemException
     */
    public function execute()
    {
        /** Add your header name here */
        $content[] = [
            'rule_id' => __('ID'),
            'name' => __('Rule'),
            'description' => __('Description'),
            'is_active' => __('Status'),
            'rule_action' => __('Rule Type'),
            'stop' => __('Stop'),
            'amount' => __('Discount Amount'),
        ];

        // $resultLayout = $this->resultLayoutFactory->create();
        // $rule = $this->ruleFactory->create()->getCollection();

        // $rule = $this->_ruleCollection->c
        
        // $collection = $this->_ruleCollection;

        // $objrules = $objectManager->create('Magento\SalesRule\Model\RuleFactory')->create();
        // $rule = $objrules->getCollection();
        
        // $rule = $this->ruleFactory->create()->addFieldToSelect('*')->load();
        // $newRule = $rule->getItems();

        // $catalogActiveRule = $this->ruleCollectionFactory->create();

        $cartPriceRule = $this->ruleCollectionFactory->create();

        

        $fileName = 'coupon_export_file.csv'; 
        $filePath =  $this->directoryList->getPath(DirectoryList::MEDIA) . "/" . $fileName;
       
        
        // print_r(                 $rule->getName()    );

        foreach ($cartPriceRule as $rule) {
        echo "<pre>";
            print_r($rule->getData());
        echo "</pre>";
            exit();
            $content[] = [
                $rule->getRuleId(),
                $rule->getName(),
                $rule->getDescription(),
                $rule->getIsActive(),
                $rule->getRuleAction(),
                $rule->getStop(),
                $rule->getAmount()
            ];
        }

        // echo "<pre>";
        // echo "Data";
        // print_r( $rule->getRuleId());
        // echo "</pre>";

        // exit();
        $this->csvProcessor->setEnclosure('"')->setDelimiter(',')->saveData($filePath, $content);
        return $this->fileFactory->create(
            $fileName,
            [
                'type'  => "filename",
                'value' => $fileName,
                'rm'    => true, 
            ],
            DirectoryList::MEDIA,
            'text/csv',
            null
        );
    }
}
