<?php
namespace Plumtree\CouponExport\Controller\Adminhtml\Index;

// use Magento\Backend\App\Action;
use Magento\Framework\App\ResponseInterface;
use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\Controller\ResultInterface;
use Magento\Framework\App\Filesystem\DirectoryList;
// use Magento\SalesRule\Model\RuleFactory;
// use Magento\SalesRule\Model\ResourceModel\Rule\CollectionFactory as RuleCollection;
use Magento\SalesRule\Model\ResourceModel\Rule\Collection;
use Magento\SalesRule\Model\ResourceModel\Rule\CollectionFactory as SalesRuleCollectionFactory;
use Magento\Framework\App\Response\Http\FileFactory;
use Magento\Framework\Stdlib\DateTime\TimezoneInterface;

 
/**
 * Class AddRow
 */
class Export extends \Magento\Framework\App\Action\Action
{
   /**
     * @var \Magento\Framework\App\Response\Http\FileFactory
     */
    protected $fileFactory;

    protected $ruleFactory;
 
    protected $ruleDataFactory;

    // protected $ruleCollectionFactory;
    /**
     * @var \Magento\SalesRule\Model\RuleFactory
     */
    // protected $ruleFactory;
    // protected $_ruleCollection;
    private $objectManager;


    /**
     * @var \Magento\Framework\View\Result\LayoutFactory
     */
    protected $resultLayoutFactory;
    /**
     * @var \Magento\Framework\File\Csv
     */
    protected $csvProcessor;
    /**
     * @var \Magento\Framework\App\Filesystem\DirectoryList
     */
    protected $directoryList;

    protected $collectionFactory;

    protected $timezone;


    /**
     * @param \Magento\Framework\App\Action\Context            $context
     * @param \Magento\Framework\App\Response\Http\FileFactory $fileFactory
     * @param \Magento\SalesRule\Model\RuleFactory             $ruleFactory
     * @param \Magento\Framework\View\Result\LayoutFactory     $resultLayoutFactory
     * @param \Magento\Framework\File\Csv                      $csvProcessor
     * @param \Magento\Framework\App\Filesystem\DirectoryList  $directoryList
     */
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\App\Response\Http\FileFactory $fileFactory,
        // \Magento\SalesRule\Model\RuleFactory $ruleFactory,
        // RuleCollection $ruleCollection,

        \Magento\Framework\View\Result\LayoutFactory $resultLayoutFactory,
        \Magento\Framework\File\Csv $csvProcessor,
        // \Magento\SalesRule\Model\ResourceModel\Rule\CollectionFactory $ruleCollectionFactory,
        \Magento\SalesRule\Model\RuleFactory $ruleFactory,
        \Magento\SalesRule\Api\Data\RuleInterfaceFactory $ruleDataFactory,

        \Magento\Framework\ObjectManagerInterface $objectmanager,

        \Magento\Framework\App\Filesystem\DirectoryList $directoryList,
        CollectionFactory $collectionFactory,
        TimezoneInterface $timezone


    ) {
        $this->fileFactory = $fileFactory;
        // $this->ruleFactory = $ruleFactory;
        // $this->_ruleCollection = $ruleCollection;
        $this->resultLayoutFactory = $resultLayoutFactory;
        $this->csvProcessor = $csvProcessor;
        $this->objectManager = $objectmanager;
        $this->ruleFactory = $ruleFactory;
        $this->ruleDataFactory = $ruleDataFactory;
        // $this->ruleCollectionFactory = $ruleCollectionFactory;
        $this->collectionFactory = $collectionFactory;
        $this->timezone = $timezone;


        $this->directoryList = $directoryList;
        parent::__construct($context);
    }
    /**
     * CSV Create and Download
     *
     * @return ResponseInterface
     * @throws \Magento\Framework\Exception\FileSystemException
     */
    public function execute()
    {
        // $collection = $this->collectionFactory->create();
        // $collection->load();

        $collection = $this->ruleFactory->create();
        // $collection->load();

        $csvData = [];
        $header = [
            'Rule ID',
            'Name',
            'Description',
            'Coupon Code',
            'Discount Amount',
            'Discount Qty',
            'Discount Step',
            'Uses per Coupon',
            'Uses per Customer',
            'From Date',
            'To Date',
            'Priority',
            'Is Active'
        ];
        $csvData[] = $header;

        foreach ($collection as $rule) {
            $csvData[] = [
                $rule->getId(),
                $rule->getName(),
                $rule->getDescription(),
                $rule->getCouponCode(),
                $rule->getDiscountAmount(),
                $rule->getDiscountQty(),
                $rule->getDiscountStep(),
                $rule->getUsesPerCoupon(),
                $rule->getUsesPerCustomer(),
                $this->timezone->date($rule->getFromDate())->format('Y-m-d H:i:s'),
                $this->timezone->date($rule->getToDate())->format('Y-m-d H:i:s'),
                $rule->getPriority(),
                $rule->getIsActive()
            ];
        }

        $fileName = 'cart_price_rules.csv';
        $directory = $this->_filesystem->getDirectoryWrite(DirectoryList::VAR_DIR);
        $path = $directory->getAbsolutePath($fileName);

        $handle = fopen($path, 'w');

        foreach ($csvData as $csvRow) {
            fputcsv($handle, $csvRow);
        }

        fclose($handle);

        return $this->fileFactory->create(
            $fileName,
            [
                'type' => 'filename',
                'value' => $path,
                'rm' => true
            ],
            DirectoryList::VAR_DIR,
            'text/csv'
        );
    }
}


