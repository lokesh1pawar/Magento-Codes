<?php
namespace Plumtree\MinicartQuote\Plugin\CustomerData;

class DefaultItemPlugin
{
    public function afterGetItemData(\Magento\Checkout\CustomerData\DefaultItem $subject, $result)
    {
        $productName = $result['product_name'];

        // Check if the product name contains '&quot;'
        if (strpos($productName, '&quot;') !== false) {
            $productName = str_replace('&quot;', '"', $productName);
        }

        $result['product_name'] = $productName;

        return $result;
    }
}
